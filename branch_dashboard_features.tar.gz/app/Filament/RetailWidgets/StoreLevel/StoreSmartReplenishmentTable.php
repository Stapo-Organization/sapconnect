<?php

namespace App\Filament\RetailWidgets\StoreLevel;

use Filament\Tables;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;
use Filament\Widgets\Concerns\InteractsWithPageFilters;
use App\Models\SapInvoiceLine;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class StoreSmartReplenishmentTable extends BaseWidget
{
    use InteractsWithPageFilters;

    protected static ?int $sort = 5;
    protected int | string | array $columnSpan = 'half';
    protected static ?string $heading = 'توصيات التحويل الذكي (Smart Replenishment)';
    protected static bool $isDiscovered = false;

    public function table(Table $table): Table
    {
        $storeCode = request()->route('storeCode');
        
        $startDate = $this->filters['startDate'] ?? Carbon::now()->startOfMonth()->toDateString();
        $endDate = $this->filters['endDate'] ?? Carbon::now()->endOfDay()->toDateString();

        $startDate = Carbon::parse($startDate)->startOfDay();
        $endDate = Carbon::parse($endDate)->endOfDay();

        return $table
            ->query(
                SapInvoiceLine::query()
                    ->join('sap_invoices', 'sap_invoice_lines.sap_invoice_id', '=', 'sap_invoices.id')
                    ->where('sap_invoices.card_code', 'C0000001')
                    ->where('sap_invoices.sales_employee_code', $storeCode)
                    ->whereBetween('sap_invoices.doc_date', [$startDate, $endDate])
                    ->select(
                        DB::raw('MAX(sap_invoice_lines.id) as id'),
                        'sap_invoice_lines.item_code',
                        DB::raw('SUM(sap_invoice_lines.quantity) as velocity')
                    )
                    ->groupBy('sap_invoice_lines.item_code')
                    ->having('velocity', '>', 5)
                    ->orderByDesc('velocity')
                    ->limit(5)
            )
            ->columns([
                Tables\Columns\TextColumn::make('item_code')
                    ->label('المنتج المقترح'),
                Tables\Columns\TextColumn::make('velocity')
                    ->label('سرعة البيع')
                    ->badge()
                    ->color('warning'),
                Tables\Columns\TextColumn::make('recommended_transfer')
                    ->label('الكمية الموصى بتحويلها')
                    ->getStateUsing(function (SapInvoiceLine $record) {
                        return ceil($record->velocity * 1.5); // Buffer mapping
                    })
                    ->badge()
                    ->color('primary')
                    ->icon('heroicon-m-truck'),
            ])
            ->paginated(false);
    }
}
