<?php

namespace App\Jobs;

use App\Models\SuggestedStockTransfer;
use App\Models\Warehouse;
use App\Services\SAP\SapClient;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CalculateStockOpportunitiesJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 3600;

    public function handle(SapClient $sapClient): void
    {
        try {
            $limit = 1000;
            $skip = 0;
            $hasMore = true;
            $currentStock = []; 

            // 1. Fetch Stock limits from SAP
            while ($hasMore) {
                $response = $sapClient->get('Items', [
                    '$select' => 'ItemCode,ItemWarehouseInfoCollection',
                    '$top' => $limit,
                    '$skip' => $skip,
                ]);

                $items = $response['value'] ?? [];
                if (empty($items)) {
                    $hasMore = false;
                    break;
                }

                foreach ($items as $item) {
                    $itemCode = $item['ItemCode'];
                    foreach ($item['ItemWarehouseInfoCollection'] as $whsInfo) {
                        $whsCode = $whsInfo['WarehouseCode'];
                        $inStock = $whsInfo['InStock'] ?? 0;
                        $currentStock[$itemCode][$whsCode] = $inStock;
                    }
                }

                $skip += $limit;
                if (count($items) < $limit) {
                    $hasMore = false;
                }
            }

            // 2. Fetch local average daily sales
            $thirtyDaysAgo = now()->subDays(30)->toDateString();
            
            $salesData = DB::table('sap_invoice_lines')
                ->join('sap_invoices', 'sap_invoice_lines.sap_invoice_id', '=', 'sap_invoices.id')
                ->join('warehouses', 'sap_invoices.sales_employee_code', '=', 'warehouses.sales_employee_code')
                ->select(
                    'sap_invoice_lines.item_code',
                    'warehouses.warehouse_code',
                    DB::raw('SUM(sap_invoice_lines.quantity) / 30 as ads')
                )
                ->whereDate('sap_invoices.doc_date', '>=', now()->subDays(60)->toDateString()) // relaxed to 60 days to match possible recent invoices
                ->groupBy('sap_invoice_lines.item_code', 'warehouses.warehouse_code')
                ->get()
                ->groupBy('item_code');

            $warehouses = Warehouse::pluck('warehouse_code')->toArray();
            
            DB::beginTransaction();
            // Delete old pending suggestions
            SuggestedStockTransfer::where('status', 'pending')->delete();

            foreach ($currentStock as $itemCode => $whsStock) {
                $itemSales = $salesData->get($itemCode)?->keyBy('warehouse_code') ?? collect();
                
                $slowMoving = [];
                $highDemand = [];

                foreach ($whsStock as $whsCode => $stock) {
                    if (!in_array($whsCode, $warehouses)) continue;

                    $ads = $itemSales->get($whsCode)->ads ?? 0;
                    $dos = $ads > 0 ? $stock / $ads : 999;
                    
                    if ($dos > 90 && $stock > 10 && $ads < 0.1) {
                        $slowMoving[] = [
                            'warehouse' => $whsCode,
                            'stock' => $stock,
                            'ads' => $ads,
                            'dos' => $dos
                        ];
                    }

                    if ($dos < 7 && $ads > 0.5) {
                        $highDemand[] = [
                            'warehouse' => $whsCode,
                            'stock' => $stock,
                            'ads' => $ads,
                            'dos' => $dos
                        ];
                    }
                }

                foreach ($highDemand as $target) {
                    foreach ($slowMoving as &$source) {
                        if ($source['stock'] <= 10) continue; 
                        
                        $requiredQty = ($target['ads'] * 30) - $target['stock'];
                        $availableQty = $source['stock'] - ($source['ads'] * 30);

                        if ($requiredQty > 0 && $availableQty > 0) {
                            $suggestedQty = min($requiredQty, $availableQty);
                            
                            if ($suggestedQty > 0) {
                                SuggestedStockTransfer::create([
                                    'item_code' => $itemCode,
                                    'source_warehouse' => $source['warehouse'],
                                    'target_warehouse' => $target['warehouse'],
                                    'suggested_quantity' => $suggestedQty,
                                    'source_ads' => $source['ads'],
                                    'source_stock' => $source['stock'],
                                    'target_ads' => $target['ads'],
                                    'target_stock' => $target['stock'],
                                ]);
                                
                                $source['stock'] -= $suggestedQty;
                                $target['stock'] += $suggestedQty;
                                break;
                            }
                        }
                    }
                }
            }
            DB::commit();

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error("CalculateStockOpportunitiesJob Failed: " . $e->getMessage());
            throw $e;
        }
    }
}
