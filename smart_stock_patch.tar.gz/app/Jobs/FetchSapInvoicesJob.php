<?php

namespace App\Jobs;

use App\Models\SapInvoice;
use App\Models\SapInvoiceLine;
use App\Services\SAP\SapClient;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class FetchSapInvoicesJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 3600; // 1 hour

    public function handle(SapClient $sapClient): void
    {
        $limit = 500;
        $skip = 0;

        try {
            // Fetch exactly latest 500 invoices, no specific card code filter to test data flow
            $response = $sapClient->get('Invoices', [
                '$select' => 'DocEntry,DocNum,CardCode,DocDate,SalesPersonCode,DocTotal,DocumentLines',
                '$top' => $limit,
                '$skip' => $skip,
                '$orderby' => 'DocEntry desc',
            ]);

            $invoices = $response['value'] ?? [];
            
            // Helpful logging
            Log::info("FetchSapInvoicesJob: Found " . count($invoices) . " invoices from SAP.");

            if (!empty($invoices)) {
                DB::beginTransaction();
                foreach ($invoices as $inv) {
                    $sapInvoice = SapInvoice::updateOrCreate(
                        ['doc_num' => $inv['DocNum']],
                        [
                            'card_code' => $inv['CardCode'] ?? null,
                            'doc_date' => $inv['DocDate'] ?? null,
                            'sales_employee_code' => $inv['SalesPersonCode'] ?? null,
                            'doc_total' => $inv['DocTotal'] ?? 0,
                        ]
                    );

                    if (isset($inv['DocumentLines']) && is_array($inv['DocumentLines'])) {
                        foreach ($inv['DocumentLines'] as $line) {
                            if (!empty($line['ItemCode'])) {
                                SapInvoiceLine::updateOrCreate(
                                    [
                                        'sap_invoice_id' => $sapInvoice->id,
                                        'item_code' => $line['ItemCode'],
                                        'warehouse_code' => $line['WarehouseCode'] ?? null,
                                    ],
                                    [
                                        'quantity' => $line['Quantity'] ?? 0,
                                    ]
                                );
                            }
                        }
                    }
                }
                DB::commit();
            }
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error("FetchSapInvoicesJob Failed: " . $e->getMessage());
        }
    }
}
