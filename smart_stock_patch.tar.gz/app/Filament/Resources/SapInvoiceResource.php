<?php

namespace App\Filament\Resources;

use App\Models\SapInvoice;
use App\Filament\Resources\SapInvoiceResource\Pages;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class SapInvoiceResource extends Resource
{
    protected static ?string $model = SapInvoice::class;

    protected static ?string $navigationIcon = 'heroicon-o-document-text';
    protected static ?string $navigationLabel = 'الفواتير المستوردة';
    protected static ?string $modelLabel = 'فاتورة';
    protected static ?string $pluralModelLabel = 'الفواتير';
    protected static ?string $navigationGroup = 'SAP Management';

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('doc_num')
                    ->label('رقم الفاتورة')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('card_code')
                    ->label('رمز العميل')
                    ->searchable(),
                Tables\Columns\TextColumn::make('sales_employee_code')
                    ->label('رمز المندوب')
                    ->searchable(),
                Tables\Columns\TextColumn::make('doc_total')
                    ->label('الإجمالي')
                    ->numeric()
                    ->sortable(),
                Tables\Columns\TextColumn::make('doc_date')
                    ->label('التاريخ')
                    ->date()
                    ->sortable(),
                Tables\Columns\TextColumn::make('created_at')
                    ->label('وقت الاستيراد')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->defaultSort('doc_num', 'desc');
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListSapInvoices::route('/'),
        ];
    }
}
