<?php

namespace App\Console\Commands;

use App\Models\Brand;
use App\Models\BrandTest;
use App\Services\SAP\SapClient;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class SyncBrands extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sap:sync-brands';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sync ItemGroups (Brands) from SAP based on active environment.';

    protected $sap;

    /**
     * Execute the console command.
     */
    public function handle(SapClient $sap)
    {
        $this->sap = $sap;

        // Respect session if running from web context (Artisan::call)
        $activeDb = session('sap_company_db', Config::get('sap.company_db'));
        $this->info("Starting Brands Sync for Active Database: $activeDb");

        // Determine Environment/Table
        $isTest = !str_contains($activeDb, 'PROD');

        if ($isTest) {
            $this->info("Detected Environment: TEST -> Syncing to 'brands_test' table.");
        } else {
            $this->info("Detected Environment: PRODUCTION -> Syncing to 'brands' table.");
        }

        try {
            $this->sap->setCompanyDb($activeDb);

            $page = 1;
            $count = 0;
            $pageSize = 100;
            $skip = 0;

            do {
                $this->info("  Fetching page $page... (Skip: $skip)");

                // Explicit pagination with sorting
                $response = $this->sap->get('ItemGroups', [
                    '$orderby' => 'Number',
                    '$top' => $pageSize,
                    '$skip' => $skip
                ]);

                $items = $response['value'] ?? [];

                if (empty($items)) {
                    break;
                }

                $fetchedCount = count($items);
                $this->info("    - Retrieved $fetchedCount records.");

                foreach ($items as $item) {
                    $envSource = $isTest ? 'test' : 'production';
                    $data = [
                        'code' => $item['Number'],
                        'name' => $item['GroupName'],
                        'source' => $envSource,
                    ];

                    if ($isTest) {
                        BrandTest::updateOrCreate(
                            ['code' => $data['code']],
                            ['name' => $data['name'], 'source' => $data['source']] // Ensure source is saved if model supports it
                        );
                    } else {
                        Brand::updateOrCreate(
                            ['code' => $data['code']],
                            ['name' => $data['name'], 'source' => $data['source']]
                        );
                    }
                    $count++;
                }

                if ($fetchedCount < $pageSize) {
                    // Less than full page means end of data
                    break;
                }

                $skip += $pageSize;
                $page++;

            } while (true);

            $this->info("Sync Completed. Processed $count records.");

        } catch (\Exception $e) {
            $this->error("Failed to sync: " . $e->getMessage());
            Log::error("Brands Sync Failed [$activeDb]: " . $e->getMessage());
        }
    }
}
