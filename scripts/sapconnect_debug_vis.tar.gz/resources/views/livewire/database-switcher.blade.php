<div class="flex items-center gap-2 mr-4" style="border: 2px solid red; z-index: 9999; position: relative;">
    <div class="relative">
        <select 
            wire:model.live="db" 
            class="block w-full rounded-lg border-none bg-white/50 py-1.5 pl-3 pr-10 text-sm text-gray-800 ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-primary-600 dark:bg-gray-800 dark:text-gray-200 dark:ring-gray-600 sm:text-sm sm:leading-6"
        >
            <option value="PPTC_V5_PROD">Production</option>
            <option value="TEST_RETAIL01">Test</option>
        </select>
        <div class="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
            @if($db === 'PPTC_V5_PROD')
                <div class="w-2 h-2 bg-green-500 rounded-full"></div>
            @else
                <div class="w-2 h-2 bg-orange-500 rounded-full"></div>
            @endif
        </div>
    </div>
</div>
