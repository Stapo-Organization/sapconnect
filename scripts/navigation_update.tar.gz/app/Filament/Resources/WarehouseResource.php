<?php

namespace App\Filament\Resources;

use App\Filament\Resources\WarehouseResource\Pages;
use App\Models\Warehouse;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class WarehouseResource extends Resource
{
    protected static ?string $model = Warehouse::class;

    protected static ?string $navigationIcon = 'heroicon-o-building-office-2';

    protected static ?string $navigationGroup = 'Master Data';

    protected static ?int $navigationSort = 3;

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('warehouse_code')
                    ->required()
                    ->maxLength(255),
                Forms\Components\TextInput::make('warehouse_name')
                    ->maxLength(255),
                Forms\Components\Select::make('source')
                    ->options([
                        'test' => 'Test Environment',
                        'production' => 'Production',
                    ])
                    ->required(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(function (Builder $query) {
                $currentDb = session('sap_company_db', config('sap.company_db'));
                $source = ($currentDb === 'PPTC_V5_PROD') ? 'production' : 'test';
                return $query->where('source', $source);
            })
            ->columns([
                Tables\Columns\TextColumn::make('warehouse_code')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('warehouse_name')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\BadgeColumn::make('source')
                    ->colors([
                        'warning' => 'test',
                        'success' => 'production',
                    ]),
                Tables\Columns\TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('updated_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('source')
                    ->options([
                        'test' => 'Test',
                        'production' => 'Production',
                    ]),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListWarehouses::route('/'),
            'create' => Pages\CreateWarehouse::route('/create'),
            'edit' => Pages\EditWarehouse::route('/{record}/edit'),
        ];
    }
}
