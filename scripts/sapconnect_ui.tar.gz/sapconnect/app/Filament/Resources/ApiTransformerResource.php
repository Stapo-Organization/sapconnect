<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ApiTransformerResource\Pages;
use App\Models\ApiTransformer;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class ApiTransformerResource extends Resource
{
    protected static ?string $model = ApiTransformer::class;

    protected static ?string $navigationIcon = 'heroicon-o-adjustments-horizontal';
    protected static ?string $navigationGroup = 'System';
    protected static ?string $label = 'API Custom View';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('Configuration')
                    ->schema([
                        Forms\Components\TextInput::make('resource')
                            ->required()
                            ->label('SAP Resource')
                            ->placeholder('e.g. Items')
                            ->helperText('The SAP entity name.'),
                        Forms\Components\TextInput::make('name')
                            ->required()
                            ->label('View Name')
                            ->placeholder('e.g. Mobile')
                            ->helperText('The ?view= parameter value.'),
                        Forms\Components\Toggle::make('is_active')
                            ->default(true)
                            ->label('Active'),
                    ])->columns(2),

                Forms\Components\Section::make('Transformation Rules')
                    ->schema([
                        Forms\Components\Repeater::make('mapping')
                            ->schema([
                                Forms\Components\Grid::make(3)
                                    ->schema([
                                        Forms\Components\TextInput::make('source')
                                            ->required()
                                            ->label('Source Field (SAP)')
                                            ->placeholder('e.g. ItemCode'),
                                        Forms\Components\TextInput::make('target')
                                            ->required()
                                            ->label('Target Field (API)')
                                            ->placeholder('e.g. id'),
                                        Forms\Components\Select::make('type')
                                            ->options([
                                                'string' => 'String',
                                                'integer' => 'Integer',
                                                'float' => 'Float',
                                                'boolean' => 'Boolean',
                                                'array' => 'List / Array',
                                            ])
                                            ->default('string')
                                            ->required()
                                            ->reactive(),
                                    ]),

                                // Nested Mapping for Arrays
                                Forms\Components\Repeater::make('sub_mapping')
                                    ->label('Nested Fields (for List/Array)')
                                    ->schema([
                                        Forms\Components\TextInput::make('source')
                                            ->label('Source Key')
                                            ->required(),
                                        Forms\Components\TextInput::make('target')
                                            ->label('Target Key')
                                            ->required(),
                                        Forms\Components\Select::make('type')
                                            ->options([
                                                'string' => 'String',
                                                'integer' => 'Integer',
                                                'float' => 'Float',
                                            ])
                                            ->default('string')
                                            ->required(),
                                    ])
                                    ->columns(3)
                                    ->visible(fn(Forms\Get $get) => $get('type') === 'array')
                                    ->defaultItems(1),
                            ])
                            ->columns(1)
                            ->defaultItems(1)
                            ->label('Field Mappings'),
                    ]),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('resource')->sortable()->searchable(),
                Tables\Columns\TextColumn::make('name')->sortable()->searchable()->label('View Name'),
                Tables\Columns\IconColumn::make('is_active')->boolean(),
                Tables\Columns\TextColumn::make('created_at')->dateTime(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListApiTransformers::route('/'),
            'create' => Pages\CreateApiTransformer::route('/create'),
            'edit' => Pages\EditApiTransformer::route('/{record}/edit'),
        ];
    }
}
