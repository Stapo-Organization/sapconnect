<?php

namespace App\Filament\Widgets;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class DatabaseStatusWidget extends BaseWidget
{
    // High priority to sit at the top
    protected static ?int $sort = -3;

    protected function getStats(): array
    {
        $db = session('sap_company_db', config('sap.company_db'));
        $isProd = $db === 'PPTC_V5_PROD';
        $username = config("sap.databases.{$db}.username", config('sap.username'));

        return [
            Stat::make('Current Database', $isProd ? 'Production' : 'Test Environment')
                ->description(($isProd ? "Connected to Live SAP Data ($db)" : "Connected to Sandbox ($db)") . "\nUser: $username")
                ->descriptionIcon($isProd ? 'heroicon-m-check-circle' : 'heroicon-m-beaker')
                ->color($isProd ? 'success' : 'warning')
                ->chart($isProd ? [7, 7, 7, 7, 7] : [3, 5, 2, 8, 4]), // Cosmetic chart
        ];
    }
}
