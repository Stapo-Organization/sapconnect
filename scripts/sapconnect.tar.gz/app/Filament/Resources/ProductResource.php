<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ProductResource\Pages;
use App\Models\Product;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class ProductResource extends Resource
{
    protected static ?string $model = Product::class;

    protected static ?string $navigationIcon = 'heroicon-o-cube';

    protected static ?string $navigationGroup = 'SAP Management';
    protected static ?int $navigationSort = 2; // After Stock Transfers (assuming it defaults to 1 or alpha)

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('item_code')
                    ->required()
                    ->maxLength(255),
                Forms\Components\TextInput::make('item_name')
                    ->maxLength(255),
                Forms\Components\TextInput::make('foreign_name')
                    ->maxLength(255),
                Forms\Components\TextInput::make('items_group_code')
                    ->numeric(),
                Forms\Components\TextInput::make('inventory_uom')
                    ->maxLength(255),
                Forms\Components\TextInput::make('piece_barcode')
                    ->maxLength(255),
                Forms\Components\TextInput::make('sales_items_per_unit')
                    ->numeric(),
                Forms\Components\DateTimePicker::make('create_date')
                    ->disabled(),
                Forms\Components\DateTimePicker::make('update_date')
                    ->disabled(),
                Forms\Components\Select::make('source')
                    ->options([
                        'test' => 'Test Environment',
                        'production' => 'Production',
                    ])
                    ->required(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(function (Builder $query) {
                // Determine current DB from session or config
                $currentDb = session('sap_company_db', config('sap.company_db'));
                $source = ($currentDb === 'PPTC_V5_PROD') ? 'production' : 'test';

                return $query->where('source', $source);
            })
            ->columns([
                Tables\Columns\TextColumn::make('item_code')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('item_name')
                    ->searchable(),
                Tables\Columns\TextColumn::make('foreign_name')
                    ->searchable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('items_group_code')
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('inventory_uom')
                    ->searchable()
                    ->toggleable(),
                Tables\Columns\TextColumn::make('piece_barcode')
                    ->searchable(),
                Tables\Columns\TextColumn::make('sales_items_per_unit'),
                Tables\Columns\TextColumn::make('create_date')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('update_date')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\BadgeColumn::make('source')
                    ->colors([
                        'warning' => 'test',
                        'success' => 'production',
                    ]),
                Tables\Columns\TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('source')
                    ->options([
                        'test' => 'Test',
                        'production' => 'Production',
                    ]),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListProducts::route('/'),
            'create' => Pages\CreateProduct::route('/create'),
            'edit' => Pages\EditProduct::route('/{record}/edit'),
        ];
    }
}
