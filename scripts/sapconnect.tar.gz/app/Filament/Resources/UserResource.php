<?php

namespace App\Filament\Resources;

use App\Filament\Resources\UserResource\Pages;
use App\Models\User;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Support\Facades\Hash;

class UserResource extends Resource
{
    protected static ?string $model = User::class;

    protected static ?string $navigationIcon = 'heroicon-o-users';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('name')
                    ->required()
                    ->maxLength(255),
                Forms\Components\TextInput::make('email')
                    ->email()
                    ->required()
                    ->maxLength(255),
                Forms\Components\TextInput::make('mobile_number')
                    ->tel()
                    ->maxLength(20)
                    ->helperText('Format: 9665...'),
                Forms\Components\TextInput::make('password')
                    ->password()
                    ->dehydrateStateUsing(fn($state) => Hash::make($state))
                    ->dehydrated(fn($state) => filled($state))
                    ->required(fn(string $context): bool => $context === 'create'),

                // Reference: Warehouse Code for Stock Transfers
                Forms\Components\TextInput::make('warehouse_code')
                    ->label('Warehouse Code')
                    ->helperText('Used for Stock Transfer permissions (Showroom Manager)')
                    ->maxLength(50),

                // Spatie Roles & Permissions (Assuming 'roles' relationship exists)
                Forms\Components\Select::make('roles')
                    ->relationship('roles', 'name')
                    ->multiple()
                    ->preload()
                    ->searchable(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')
                    ->searchable()
                    ->description(fn(User $record) => $record->email),
                Tables\Columns\TextColumn::make('mobile_number')
                    ->searchable(),

                Tables\Columns\IconColumn::make('last_activity_at')
                    ->label('Online Status')
                    ->state(function (User $record) {
                        if ($record->last_activity_at && $record->last_activity_at->diffInMinutes(now()) < 5) {
                            return true;
                        }
                        return false;
                    })
                    ->icon(fn(bool $state): string => $state ? 'heroicon-s-check-circle' : 'heroicon-s-x-circle')
                    ->color(fn(bool $state): string => $state ? 'success' : 'gray')
                    ->trueIcon('heroicon-s-check-circle') // Green dot equivalent
                    ->falseIcon('heroicon-o-x-circle'),

                Tables\Columns\TextColumn::make('last_login_at')
                    ->label('Last Login')
                    ->dateTime()
                    ->sortable()
                    ->since(), // Show "2 minutes ago"

                Tables\Columns\TextColumn::make('roles.name')
                    ->badge(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListUsers::route('/'),
            'create' => Pages\CreateUser::route('/create'),
            'edit' => Pages\EditUser::route('/{record}/edit'),
        ];
    }
}
