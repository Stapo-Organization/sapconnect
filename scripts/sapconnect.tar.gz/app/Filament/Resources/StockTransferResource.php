<?php

namespace App\Filament\Resources;

use App\Filament\Resources\StockTransferResource\Pages;
use App\Models\StockTransfer;
use App\Models\StockTransferLine;
use App\Services\StockTransferService;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Filament\Notifications\Notification;

class StockTransferResource extends Resource
{
    protected static ?string $model = StockTransfer::class;

    protected static ?string $navigationIcon = 'heroicon-o-truck';

    protected static ?string $navigationLabel = 'Stock Transfers';

    protected static ?string $navigationGroup = 'SAP Management';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('Transfer Details')
                    ->columns(2)
                    ->schema([
                        Forms\Components\TextInput::make('doc_num')
                            ->label('Document Number')
                            ->disabled(),
                        Forms\Components\TextInput::make('document_status')
                            ->label('Status')
                            ->disabled(),
                        Forms\Components\TextInput::make('from_warehouse')
                            ->label('From Warehouse')
                            ->disabled(),
                        Forms\Components\TextInput::make('to_warehouse')
                            ->label('To Warehouse')
                            ->disabled(),
                        Forms\Components\DatePicker::make('doc_date')
                            ->label('Document Date')
                            ->disabled(),
                    ]),

                Forms\Components\Section::make('Items')
                    ->schema([
                        Forms\Components\Repeater::make('lines')
                            ->relationship()
                            ->schema([
                                Forms\Components\Grid::make(4)
                                    ->schema([
                                        Forms\Components\TextInput::make('item_code')
                                            ->label('Item Code')
                                            ->disabled(),
                                        Forms\Components\TextInput::make('item_description')
                                            ->label('Description')
                                            ->disabled(),
                                        Forms\Components\TextInput::make('quantity')
                                            ->label('Sent Quantity')
                                            ->numeric()
                                            ->disabled(),
                                        Forms\Components\TextInput::make('received_quantity')
                                            ->label('Received Quantity')
                                            ->numeric()
                                            ->default(0)
                                            ->minValue(0)
                                            ->required(),
                                    ]),
                            ])
                            ->addable(false)
                            ->deletable(false)
                            ->columnSpanFull(),
                    ]),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('doc_num')->label('Doc Num')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('from_warehouse')->label('From')->searchable(),
                Tables\Columns\TextColumn::make('to_warehouse')->label('To')->searchable(),
                Tables\Columns\TextColumn::make('doc_date')->label('Date')->date()->sortable(),
                Tables\Columns\TextColumn::make('document_status')->label('Status')
                    ->badge()
                    ->colors([
                        'success' => 'O', // Open?
                        'danger' => 'C', // Closed?
                    ]),
                Tables\Columns\TextColumn::make('created_at')->dateTime()->sortable()->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                // Filter by Warehouse for admins?
            ])
            ->headerActions([
                Tables\Actions\Action::make('import_from_sap')
                    ->label('Import from SAP')
                    ->icon('heroicon-o-arrow-down-tray')
                    ->action(function () {
                        try {
                            $service = app(StockTransferService::class);
                            $result = $service->importFromSap();

                            // Handle legacy return (int) if deploy is partial, but we expect array now
                            if (is_int($result)) {
                                $msg = "Imported $result records.";
                            } else {
                                $msg = "DB: {$result['active_db']} | Total: {$result['total']} | Imported: {$result['imported']} | Skipped: {$result['skipped']}";
                                if ($result['sample_date']) {
                                    $msg .= " | Sample Date: {$result['sample_date']}";
                                }
                            }

                            Notification::make()
                                ->title('Import Result')
                                ->body($msg)
                                ->success()
                                ->persistent() // Keep it visible for debugging
                                ->send();
                        } catch (\Exception $e) {
                            Notification::make()
                                ->title('Import Failed')
                                ->body($e->getMessage())
                                ->danger()
                                ->send();
                        }
                    }),
            ])
            ->actions([
                Tables\Actions\EditAction::make()->label('Receive'),
            ])
            ->bulkActions([
                //
            ])
            ->modifyQueryUsing(function (Builder $query) {
                $user = auth()->user();
                if ($user && $user->warehouse_code) {
                    // Filter: show transfers WHERE to_warehouse == user->warehouse_code
                    $query->where('to_warehouse', $user->warehouse_code);
                }
                return $query;
            });
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListStockTransfers::route('/'),
            'create' => Pages\CreateStockTransfer::route('/create'), // Not really used
            'edit' => Pages\EditStockTransfer::route('/{record}/edit'),
        ];
    }
}
