<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ApiTransformerResource\Pages;
use App\Models\ApiTransformer;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class ApiTransformerResource extends Resource
{
    protected static ?string $model = ApiTransformer::class;

    protected static ?string $navigationIcon = 'heroicon-o-adjustments-horizontal';
    protected static ?string $navigationGroup = 'System';
    protected static ?string $label = 'API Custom View';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('Configuration')
                    ->schema([
                        Forms\Components\TextInput::make('resource')
                            ->required()
                            ->label('SAP Resource')
                            ->placeholder('e.g. Items')
                            ->helperText('The SAP entity name.')
                            ->live(onBlur: true), // Live update to trigger schema fetch
                        Forms\Components\TextInput::make('name')
                            ->required()
                            ->label('View Name')
                            ->placeholder('e.g. Mobile')
                            ->helperText('The ?view= parameter value.'),
                        Forms\Components\Toggle::make('is_active')
                            ->default(true)
                            ->label('Active'),
                    ])->columns(2),

                Forms\Components\Section::make('Transformation Rules')
                    ->schema([
                        Forms\Components\Repeater::make('mapping')
                            ->schema([
                                Forms\Components\Grid::make(3)
                                    ->schema([
                                        Forms\Components\TextInput::make('source')
                                            ->required()
                                            ->label('Source Field (SAP)')
                                            ->placeholder('Select or Type...')
                                            ->datalist(function (Forms\Get $get) {
                                                $resource = $get('../../resource');
                                                if (!$resource)
                                                    return [];

                                                return cache()->remember("sap_schema_{$resource}", 60, function () use ($resource) {
                                                    try {
                                                        $sap = app(\App\Services\SAP\SapClient::class);
                                                        // Fetch 1 item to get schema
                                                        $data = $sap->get($resource, ['$top' => 1]);
                                                        $item = $data['value'][0] ?? null;
                                                        if (!$item)
                                                            return [];
                                                        $keys = array_keys($item);
                                                        return $keys;
                                                    } catch (\Exception $e) {
                                                        return [];
                                                    }
                                                });
                                            })
                                            ->live()
                                            ->afterStateUpdated(function (Forms\Set $set, Forms\Get $get, $state) {
                                                // Auto-detect type
                                                $resource = $get('../../resource');
                                                if (!$resource || !$state)
                                                    return;

                                                try {
                                                    $sap = app(\App\Services\SAP\SapClient::class);
                                                    // We rely on cache hopefully populated above
                                                    $data = $sap->get($resource, ['$top' => 1]);
                                                    $item = $data['value'][0] ?? [];
                                                    $val = $item[$state] ?? null;

                                                    if (is_array($val))
                                                        $set('type', 'array');
                                                    elseif (is_bool($val))
                                                        $set('type', 'boolean');
                                                    elseif (is_int($val))
                                                        $set('type', 'integer');
                                                    elseif (is_float($val))
                                                        $set('type', 'float');
                                                    else
                                                        $set('type', 'string');

                                                    // Auto-set target to same name if empty
                                                    if (!$get('target'))
                                                        $set('target', $state);
                                                } catch (\Exception $e) {
                                                }
                                            }),

                                        Forms\Components\TextInput::make('target')
                                            ->required()
                                            ->label('Target Field (API)')
                                            ->placeholder('e.g. id'),
                                        Forms\Components\Select::make('type')
                                            ->options([
                                                'string' => 'String',
                                                'integer' => 'Integer',
                                                'float' => 'Float',
                                                'boolean' => 'Boolean',
                                                'array' => 'List / Array',
                                            ])
                                            ->default('string')
                                            ->required()
                                            ->reactive(),
                                    ]),

                                // Nested Mapping for Arrays
                                Forms\Components\Repeater::make('sub_mapping')
                                    ->label('Nested Fields (for List/Array)')
                                    ->schema([
                                        Forms\Components\TextInput::make('source')
                                            ->label('Source Key')
                                            ->required()
                                            ->datalist(function (Forms\Get $get) {
                                                $resource = $get('../../../resource');
                                                $parentSource = $get('../source');
                                                if (!$resource || !$parentSource)
                                                    return [];

                                                return cache()->remember("sap_schema_{$resource}_{$parentSource}", 60, function () use ($resource, $parentSource) {
                                                    try {
                                                        $sap = app(\App\Services\SAP\SapClient::class);
                                                        $data = $sap->get($resource, ['$top' => 1]);
                                                        $item = $data['value'][0] ?? [];
                                                        $subItem = $item[$parentSource][0] ?? null; // Assume array of objects
                                                        if (!$subItem || !is_array($subItem))
                                                            return [];
                                                        $keys = array_keys($subItem);
                                                        return $keys;
                                                    } catch (\Exception $e) {
                                                        return [];
                                                    }
                                                });
                                            })
                                            ->live()
                                            ->afterStateUpdated(function (Forms\Set $set, Forms\Get $get, $state) {
                                                // Auto-detect type nested
                                                $resource = $get('../../../resource');
                                                $parentSource = $get('../source');
                                                if (!$resource || !$parentSource || !$state)
                                                    return;

                                                try {
                                                    $sap = app(\App\Services\SAP\SapClient::class);
                                                    $data = $sap->get($resource, ['$top' => 1]);
                                                    $item = $data['value'][0] ?? [];
                                                    $subItem = $item[$parentSource][0] ?? [];
                                                    $val = $subItem[$state] ?? null;

                                                    if (is_int($val))
                                                        $set('type', 'integer');
                                                    elseif (is_float($val))
                                                        $set('type', 'float');
                                                    else
                                                        $set('type', 'string');

                                                    if (!$get('target'))
                                                        $set('target', $state);
                                                } catch (\Exception $e) {
                                                }
                                            }),
                                        Forms\Components\TextInput::make('target')
                                            ->label('Target Key')
                                            ->required(),
                                        Forms\Components\Select::make('type')
                                            ->options([
                                                'string' => 'String',
                                                'integer' => 'Integer',
                                                'float' => 'Float',
                                            ])
                                            ->default('string')
                                            ->required(),
                                    ])
                                    ->columns(3)
                                    ->visible(fn(Forms\Get $get) => $get('type') === 'array')
                                    ->defaultItems(1),
                            ])
                            ->columns(1)
                            ->defaultItems(1)
                            ->label('Field Mappings'),
                    ]),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('resource')->sortable()->searchable(),
                Tables\Columns\TextColumn::make('name')->sortable()->searchable()->label('View Name'),
                Tables\Columns\IconColumn::make('is_active')->boolean(),
                Tables\Columns\TextColumn::make('created_at')->dateTime(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListApiTransformers::route('/'),
            'create' => Pages\CreateApiTransformer::route('/create'),
            'edit' => Pages\EditApiTransformer::route('/{record}/edit'),
        ];
    }
}
