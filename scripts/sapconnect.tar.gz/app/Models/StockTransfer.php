<?php

namespace App\Models;

use App\Services\SAP\SapClient;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Session;

class StockTransfer extends Model
{
    use HasFactory;

    protected $guarded = [];

    /**
     * Get the table associated with the model.
     * Dynamically switches between 'sap_stock_transfers_test' and 'sap_stock_transfers_prod'
     * based on the active SAP Company DB.
     *
     * @return string
     */
    public function getTable()
    {
        // Determine environment based on session or config
        // Default to 'test' if not found for safety, or check specific DB names.

        $companyDb = app(SapClient::class)->getCompanyDb();

        // Logic: specific DB names identify PROD vs TEST
        // As per request: TEST_RETAIL01 vs PPTC_V5_PROD

        if ($companyDb === 'PPTC_V5_PROD') {
            return 'sap_stock_transfers_prod';
        }

        // Default to test for TEST_RETAIL01 or any others
        return 'sap_stock_transfers_test';
    }

    public function lines()
    {
        // We must manually specify the related table or use a dynamic related model
        // Since Eloquent caches relationships, we need a Dynamic Line model too.
        return $this->hasMany(StockTransferLine::class, 'stock_transfer_id');
    }

    /**
     * Get the source warehouse associated with the stock transfer.
     */
    public function fromWarehouse()
    {
        $source = ($this->getTable() === 'sap_stock_transfers_prod') ? 'production' : 'test';
        return $this->belongsTo(Warehouse::class, 'from_warehouse', 'warehouse_code')
            ->where('source', $source);
    }

    /**
     * Get the destination warehouse associated with the stock transfer.
     */
    public function toWarehouse()
    {
        $source = ($this->getTable() === 'sap_stock_transfers_prod') ? 'production' : 'test';
        return $this->belongsTo(Warehouse::class, 'to_warehouse', 'warehouse_code')
            ->where('source', $source);
    }
}
