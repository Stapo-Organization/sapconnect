<?php

namespace App\Models;

use App\Services\SAP\SapClient;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StockTransferLine extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function getTable()
    {
        $companyDb = app(SapClient::class)->getCompanyDb();

        if ($companyDb === 'PPTC_V5_PROD') {
            return 'sap_stock_transfer_lines_prod';
        }

        return 'sap_stock_transfer_lines_test';
    }

    public function transfer()
    {
        return $this->belongsTo(StockTransfer::class, 'stock_transfer_id');
    }
}
