<?php

namespace App\Services\Sms;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class TaqnyatSmsService
{
    protected $baseUrl = 'https://api.taqnyat.sa/v1';
    protected $bearerToken = '60cad7ddd1d6300aec7c96750ea8c922';
    protected $sender = 'PPTCO';

    public function sendOtp($mobile, $otp)
    {
        // Normalize mobile if needed, but assuming controller handles it mostly.
        // API format: 96650xxxxxxx

        $message = "Your OTP code is: {$otp}";

        try {
            $response = Http::get("{$this->baseUrl}/messages", [
                'bearerTokens' => $this->bearerToken,
                'sender' => $this->sender,
                'recipients' => $mobile,
                'body' => $message,
            ]);

            if ($response->successful()) {
                Log::info("SMS sent successfully to {$mobile}");
                return true;
            } else {
                Log::error("Failed to send SMS to {$mobile}: " . $response->body());
                return false;
            }
        } catch (\Exception $e) {
            Log::error("Exception sending SMS to {$mobile}: " . $e->getMessage());
            return false;
        }
    }
}
