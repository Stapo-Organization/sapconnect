<?php

namespace App\Services;

use App\Models\StockTransfer;
use App\Models\StockTransferLine;
use App\Services\SAP\SapClient;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class StockTransferService
{
    protected $sap;

    public function __construct(SapClient $sap)
    {
        $this->sap = $sap;
    }

    public function importFromSap()
    {
        Log::info("StockTransferService: Starting Import...");

        $activeDb = $this->sap->getCompanyDb();

        // Default constraints
        $minDate = Carbon::parse('2025-12-01');
        $params = [
            '$filter' => "CreationDate gt '2025-12-01'",
            '$top' => 20 
        ];

        // Conditional for TEST_RETAIL01: Fetch first 20 records without date restriction
        if ($activeDb === 'TEST_RETAIL01') { 
             $params = [
                '$top' => 20
             ];
             $minDate = null; 
        }

        $count = 0;
        $skipped = 0;
        $sampleDate = null;
        $totalFetched = 0;

        try {
            // Initial Request
            $skip = 0;
            $top = 20;

            do {
                // Update params for current page
                $params['$skip'] = $skip;
                $params['$top'] = $top;

                Log::info("StockTransferService: Fetching page... Skip: $skip, Top: $top");

                $response = $this->sap->get('StockTransfers', $params);

                $data = $response['value'] ?? []; // Array of records

                if (!is_array($data)) {
                    Log::error("StockTransferService: Invalid response format", ['response' => $response]);
                    break;
                }

                $pageCount = count($data);
                $totalFetched += $pageCount;
                Log::info("StockTransferService: Page fetched with $pageCount records.");

                foreach ($data as $index => $row) {
                    $creationDateRaw = $row['CreationDate'] ?? null;
                    if (!$sampleDate)
                        $sampleDate = $creationDateRaw;

                    if (!$creationDateRaw) {
                        $skipped++;
                        continue;
                    }

                    $creationDate = Carbon::parse($creationDateRaw);

                    if ($minDate && $creationDate->lt($minDate)) {
                        $skipped++;
                        continue;
                    }

                    $this->syncStockTransfer($row);
                    $count++;
                }

                // Increment Skip
                $skip += $top;

                // Break if we fetched fewer than requested (End of Data)
            } while ($pageCount >= $top);

            Log::info("StockTransferService: Import Complete. Total Fetched: $totalFetched, Imported: $count, Skipped: $skipped.");

            return [
                'imported' => $count,
                'skipped' => $skipped,
                'total' => $totalFetched,
                'active_db' => $activeDb,
                'sample_date' => $sampleDate
            ];

        } catch (\Exception $e) {
            Log::error("StockTransferService: Import Failed: " . $e->getMessage());
            throw $e;
        }
    }

    protected function syncStockTransfer($row)
    {
        // DB Transaction for safety
        DB::transaction(function () use ($row) {
            // 1. Create/Update Header
            // We use DocEntry as unique key

            $transfer = StockTransfer::updateOrCreate(
                ['doc_entry' => $row['DocEntry']],
                [
                    'doc_num' => $row['DocNum'],
                    'from_warehouse' => $row['FromWarehouse'] ?? null,
                    'to_warehouse' => $row['ToWarehouse'] ?? null,
                    'doc_date' => isset($row['DocDate']) ? Carbon::parse($row['DocDate'])->format('Y-m-d') : null,
                    'document_status' => $row['DocumentStatus'] ?? null,
                    'creation_date' => isset($row['CreationDate']) ? Carbon::parse($row['CreationDate']) : null,
                    'update_date' => isset($row['UpdateDate']) ? Carbon::parse($row['UpdateDate']) : null,
                ]
            );

            // 2. Sync Lines
            // Strategy: Delete existing lines and re-create? Or Update?
            // Re-creating is safer for syncing arrays unless we have unique LineNum
            // Custom view usually returns 'StockTransferLines' array

            $lines = $row['StockTransferLines'] ?? [];

            // Get existing received quantities to preserve them if we re-create
            // Actually, if we delete, we lose 'received_quantity'. 
            // WE MUST PRESERVE 'received_quantity'.

            // Map existing lines by ItemCode or LineNum? 
            // The custom view schema in migration showed: ItemCode, ItemDescription, Quantity, FromWarehouseCode, WarehouseCode, LineStatus
            // It does NOT show LineNum. This is risky. 
            // Let's assume (ItemCode) is unique per transfer? No, could be multiple lines same Item.
            // We really need LineNum. 
            // Looking at the migration `2025_01_01_000012_seed_stock_transfer_view.php`, it does NOT map LineNum.
            // Problem: If I delete lines, I lose user input (received_quantity).

            // Solution: 
            // 1. If the transfer is 'Closed' or 'Canceled' in SAP, maybe we don't care?
            // 2. If Open, we iterate.
            // Since we don't have LineNum in custom view mapping (checked migration), 
            // We will try to match by ItemCode + Quantity + Warehouse?
            // Or, simplistic approach:
            // Since this is an IMPORT, validation against SAP is key.
            // If the user has partially received, and SAP updates, we have a conflict.

            // Assumption for MVP: 
            // Allow update of Header status. 
            // Only add NEW lines? 
            // Or match by ItemCode. 

            // Let's try to match by ItemCode.

            $existingLines = $transfer->lines()->get()->keyBy('item_code'); // Key by ItemCode (First hit)
            // Warning: If duplicates exist, this breaks.

            // For now, let's implement strict matching.
            // But wait, if I don't have LineNum, I can't reliably update line 2 of same item.

            // Let's blindly delete and recreate EXCEPT if 'received_quantity' > 0?
            // If 'received_quantity' > 0, we should probably keep it.

            // Better approach:
            // Fetch current lines. 
            // Iterate incoming. 
            // Match with first Unmatched existing line with same ItemCode.
            // Update fields.
            // If match found, remove from "pool" of existing lines.
            // After loop, delete remaining existing lines (that disappeared from SAP).

            $currentLines = $transfer->lines()->get(); // Collection
            $matchedIds = [];

            foreach ($lines as $lineIndex => $lineData) {
                // Log::info("Processing line $lineIndex", ['item' => $lineData['ItemCode'] ?? 'N/A']);

                $itemCode = $lineData['ItemCode'];

                // Find match in $currentLines that is NOT in $matchedIds
                $match = $currentLines->first(function ($l) use ($itemCode, $matchedIds) {
                    return $l->item_code === $itemCode && !in_array($l->id, $matchedIds);
                });

                if ($match) {
                    // Update
                    $match->update([
                        'item_description' => $lineData['ItemDescription'] ?? $match->item_description,
                        'quantity' => $lineData['Quantity'] ?? $match->quantity,
                        'from_warehouse_code' => $lineData['FromWarehouseCode'] ?? $match->from_warehouse_code,
                        'warehouse_code' => $lineData['WarehouseCode'] ?? $match->warehouse_code, // To Warehouse
                        'line_status' => $lineData['LineStatus'] ?? $match->line_status,
                    ]);
                    $matchedIds[] = $match->id;
                } else {
                    // Create New
                    try {
                        $newLine = $transfer->lines()->create([
                            'item_code' => $itemCode,
                            'item_description' => $lineData['ItemDescription'] ?? null,
                            'quantity' => $lineData['Quantity'] ?? 0,
                            'received_quantity' => 0, // Default
                            'from_warehouse_code' => $lineData['FromWarehouseCode'] ?? null,
                            'warehouse_code' => $lineData['WarehouseCode'] ?? null,
                            'line_status' => $lineData['LineStatus'] ?? null,
                        ]);
                        $matchedIds[] = $newLine->id; // CRITICAL FIX: Protect new line from deletion
                    } catch (\Exception $e) {
                        Log::error("Failed to create line: " . $e->getMessage());
                        throw $e;
                    }
                }
            }
            Log::info("StockTransfer {$row['DocNum']} Synced. Lines processed: " . count($lines));


            // Delete lines that no longer exist in SAP
            $transfer->lines()->whereNotIn('id', $matchedIds)->delete();

        });
    }
}
