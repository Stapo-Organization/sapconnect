<?php

use App\Http\Controllers\Api\UniversalSapController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// Auth Routes
Route::post('/login', [\App\Http\Controllers\Api\AuthController::class, 'login']);
Route::post('/verify-otp', [\App\Http\Controllers\Api\AuthController::class, 'verifyOtp']);

// SAP Integration Routes
// Protected by Custom App Token and LogSapRequests middleware
Route::middleware(['auth.app_token', \App\Http\Middleware\LogSapRequests::class])->prefix('sap')->group(function () {

    // Generic Resource Handler
    // Matches /api/sap/Orders, /api/sap/BusinessPartners, etc.
    Route::get('/{resource}', [UniversalSapController::class, 'index']);
    Route::post('/{resource}', [UniversalSapController::class, 'store']);
    Route::patch('/{resource}/{id}', [UniversalSapController::class, 'update']);

    // Add specific custom controllers below if needed overriding the generic ones
    // Route::get('Inventory', [InventoryController::class, 'index']);
});
