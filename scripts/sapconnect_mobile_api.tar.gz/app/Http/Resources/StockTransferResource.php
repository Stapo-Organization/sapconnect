<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class StockTransferResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'doc_entry' => $this->doc_entry,
            'doc_num' => $this->doc_num,
            'from_warehouse' => $this->from_warehouse,
            'to_warehouse' => $this->to_warehouse,
            'doc_date' => $this->doc_date,
            'document_status' => $this->document_status,
            'creation_date' => $this->creation_date,
            'lines' => StockTransferLineResource::collection($this->whenLoaded('lines')),
        ];
    }
}
