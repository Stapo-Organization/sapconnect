<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\StockTransferResource;
use App\Models\StockTransfer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StockTransferController extends Controller
{
    /**
     * List Stock Transfers
     * 
     * Retrieve a list of stock transfers for the user's warehouse.
     * 
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection<\App\Http\Resources\StockTransferResource>
     */
    public function index(Request $request)
    {
        $user = $request->user();

        // Ensure user has a warehouse assigned
        if (!$user->warehouse_code) {
            // Return empty or error depending on requirement. Returning empty for now.
            return StockTransferResource::collection([]);
        }

        $transfers = StockTransfer::query()
            ->where('to_warehouse', $user->warehouse_code)
            ->with('lines') // Eager load if needed for list, or lazy load
            ->latest('doc_date')
            ->paginate(20);

        return StockTransferResource::collection($transfers);
    }

    /**
     * Get Stock Transfer Details
     * 
     * Retrieve details of a specific stock transfer.
     * 
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \App\Http\Resources\StockTransferResource
     */
    public function show(Request $request, $id)
    {
        $user = $request->user();

        $transfer = StockTransfer::query()
            ->with('lines')
            ->where('id', $id)
            // Security check: ensure restricted to user's warehouse
            ->when($user->warehouse_code, function ($query) use ($user) {
                $query->where('to_warehouse', $user->warehouse_code);
            })
            ->firstOrFail();

        return new StockTransferResource($transfer);
    }

    /**
     * Receive Items
     * 
     * Update received quantities for items in a stock transfer.
     * 
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \App\Http\Resources\StockTransferResource
     */
    public function receive(Request $request, $id)
    {
        $user = $request->user();

        $transfer = StockTransfer::query()
            ->where('id', $id)
            ->when($user->warehouse_code, function ($query) use ($user) {
                $query->where('to_warehouse', $user->warehouse_code);
            })
            ->firstOrFail();

        $request->validate([
            'items' => 'required|array',
            'items.*.id' => 'required|integer', // Line ID
            'items.*.received_quantity' => 'required|numeric|min:0',
        ]);

        DB::transaction(function () use ($transfer, $request) {
            foreach ($request->items as $itemData) {
                // Find the line associated with this transfer
                $line = $transfer->lines()->where('id', $itemData['id'])->first();

                if ($line) {
                    $line->update([
                        'received_quantity' => $itemData['received_quantity'],
                        // Potential logic: update status if fully received
                    ]);
                }
            }
        });

        // Reload to get updated quantities
        $transfer->load('lines');

        return new StockTransferResource($transfer);
    }
}
