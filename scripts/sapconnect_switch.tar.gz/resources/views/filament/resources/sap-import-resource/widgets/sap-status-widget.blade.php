<x-filament::widget class="fi-sap-status-widget">
    @php
        $db = session('sap_company_db', config('sap.company_db'));
        $isProd = $db === 'PPTC_V5_PROD';
        $color = $isProd ? 'bg-green-600' : 'bg-orange-500';
        $label = $isProd ? 'Production DB' : 'Test DB';
    @endphp

    <div
        class="fixed bottom-4 right-4 z-50 flex items-center gap-x-3 px-4 py-3 text-white rounded-lg shadow-lg opacity-90 hover:opacity-100 transition-opacity {{ $color }}">
        <x-heroicon-o-server class="w-6 h-6 animate-pulse" />
        <div class="flex flex-col">
            <span class="text-xs font-semibold uppercase tracking-wider opacity-80">Connected To</span>
            <span class="font-bold text-sm">{{ $label }}</span>
            <span class="text-[10px] opacity-75">{{ $db }}</span>
        </div>
    </div>
</x-filament::widget>