<?php

namespace App\Livewire;

use Livewire\Component;
use Filament\Notifications\Notification;

class DatabaseSwitcher extends Component
{
    public $db;

    public function mount()
    {
        $this->db = session('sap_company_db', config('sap.company_db'));
    }

    public function updatedDb($value)
    {
        session(['sap_company_db' => $value]);

        Notification::make()
            ->title('Environment Switched')
            ->body("Switched to active environment: " . ($value === 'PPTC_V5_PROD' ? 'Production' : 'Test'))
            ->success()
            ->send();

        return redirect(request()->header('Referer'));
    }

    public function render()
    {
        return view('livewire.database-switcher');
    }
}
