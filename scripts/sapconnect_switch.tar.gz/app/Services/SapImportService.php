<?php

namespace App\Services;

use App\Models\SapImport;
use App\Models\ApiLog;
use App\Services\SAP\SapClient;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;

class SapImportService
{
    protected $sap;

    public function __construct()
    {
        $this->sap = app(SapClient::class);
    }

    public function setDatabase($db)
    {
        $this->sap->setCompanyDb($db);
    }

    public function process(SapImport $import, $filePath, array $params = [], $dryRun = false)
    {
        // Resolve Path Logic
        $realPath = null;
        if (file_exists($filePath)) {
            $realPath = $filePath;
        } elseif (Storage::disk('local')->exists($filePath)) {
            $realPath = Storage::disk('local')->path($filePath);
        } elseif (Storage::exists($filePath)) {
            $realPath = Storage::path($filePath);
        }

        if (!$realPath) {
            throw new \Exception("File not found at path: $filePath. Please try uploading again.");
        }

        // Fix line endings for MAC/Unix/Windows compat
        ini_set('auto_detect_line_endings', true);

        $rows = array_map('str_getcsv', file($realPath));
        if (!$rows)
            throw new \Exception("CSV file is invalid or empty.");

        $header = array_shift($rows);
        if (!$header)
            throw new \Exception("CSV file is empty or invalid header.");

        $header = array_map('trim', $header);

        // Remove BOM from first header if present
        if (isset($header[0])) {
            $header[0] = preg_replace('/^\xEF\xBB\xBF/', '', $header[0]);
        }

        Log::info("SapImportService: Header Detected", ['header' => $header]);
        if (!empty($rows)) {
            Log::info("SapImportService: First Row Raw", ['row' => $rows[0]]);
        }

        $mappedData = [];

        foreach ($rows as $index => $row) {
            // Skip empty rows (all columns empty)
            if (
                empty(array_filter($row, function ($v) {
                    return trim($v) !== '';
                }))
            ) {
                continue;
            }

            if (count($row) !== count($header)) {
                Log::warning("SapImportService: Row $index count mismatch", ['expected' => count($header), 'actual' => count($row), 'row' => $row]);
                continue;
            }

            $rowAssoc = array_combine($header, $row);
            $item = [];
            foreach ($import->mapping as $map) {
                $csvKey = trim($map['csv_header']); // Ensure trim
                $sapKey = $map['sap_field'];

                // Case-insensitive check fallback?
                if (isset($rowAssoc[$csvKey])) {
                    $value = $rowAssoc[$csvKey];
                } else {
                    // Try case-insensitive lookup
                    $lowerKey = strtolower($csvKey);
                    $foundKey = null;
                    foreach (array_keys($rowAssoc) as $hKey) {
                        if (strtolower($hKey) === $lowerKey) {
                            $foundKey = $hKey;
                            break;
                        }
                    }
                    $value = $foundKey ? $rowAssoc[$foundKey] : null;
                }

                if ($value !== null) {
                    // Clean Date? If SAP field contains 'Date'
                    if (str_contains($sapKey, 'Date') && strlen($value) > 10) {
                        $value = substr($value, 0, 10);
                    }
                    if (is_numeric($value)) {
                        $value = strpos($value, '.') !== false ? (float) $value : (int) $value;
                    }
                    data_set($item, $sapKey, $value);
                }
            }
            if (!empty($item)) {
                $mappedData[] = $item;
            }
        }

        if (!empty($mappedData)) {
            Log::info("SapImportService: First Mapped Item", ['item' => $mappedData[0]]);
        }

        if ($import->import_mode === 'Single') {
            $successCount = 0;
            $previewPayloads = [];

            foreach ($mappedData as $payload) {
                // Merge Params
                foreach ($params as $k => $v) {
                    data_set($payload, $k, $v);
                }

                if ($dryRun) {
                    $previewPayloads[] = $payload;
                    continue;
                }

                try {
                    $response = $this->sap->post($import->resource, $payload);
                    $this->logActivity($import->resource, $payload, $response, 201);
                    $successCount++;
                } catch (\Throwable $e) {
                    $this->logActivity($import->resource, $payload, ['error' => $e->getMessage()], 500);
                    // Continue or throw? Continue for bulk best effort?
                    // Let's count success only.
                }
            }

            if ($dryRun)
                return $previewPayloads;

            return $successCount;
        } elseif ($import->import_mode === 'Document') {
            $groupedDocs = [];
            foreach ($mappedData as $data) {
                $rootKeys = [];
                foreach ($data as $k => $v) {
                    if (!is_array($v))
                        $rootKeys[$k] = $v;
                }
                ksort($rootKeys);
                $sig = json_encode($rootKeys);
                $groupedDocs[$sig][] = $data;
            }

            $count = 0;
            $previewPayloads = [];

            foreach ($groupedDocs as $docRows) {
                $payload = $this->mergeRowsToDocument($docRows);

                // Merge Params into Document Root
                foreach ($params as $k => $v) {
                    data_set($payload, $k, $v);
                }

                // Auto-Sum for InventoryCountings
                if (str_contains($import->resource, 'InventoryCountings') && isset($payload['InventoryCountingLines'])) {
                    foreach ($payload['InventoryCountingLines'] as &$line) {
                        if (isset($line['BatchNumbers']) && is_array($line['BatchNumbers'])) {
                            $sum = 0;
                            foreach ($line['BatchNumbers'] as $batch) {
                                $sum += (float) ($batch['Quantity'] ?? 0);
                            }
                            $line['CountedQuantity'] = $sum;
                        }
                    }
                }

                try {
                    $this->enrichBatchData($import, $payload);

                    if ($dryRun) {
                        $previewPayloads[] = $payload;
                        continue;
                    }

                    $response = $this->sap->post($import->resource, $payload);
                    $this->logActivity($import->resource, $payload, $response, 201);
                    $count++;
                } catch (\Throwable $e) {
                    if ($dryRun)
                        throw $e; // Re-throw during preview

                    $this->logActivity($import->resource, $payload, ['error' => $e->getMessage()], 500);
                    throw $e; // Throw for single document failure
                }
            }

            if ($dryRun)
                return $previewPayloads;

            return $count;
        }

        return 0;
    }

    protected function enrichBatchData(SapImport $import, array &$payload)
    {
        if (!$import->auto_batch_enrichment) {
            return;
        }

        // Support for InventoryCountings
        if (str_contains($import->resource, 'InventoryCountings') && isset($payload['InventoryCountingLines'])) {
            foreach ($payload['InventoryCountingLines'] as &$line) {
                // Check both keys during transition or mapping
                $batches = $line['InventoryCountingBatchNumbers'] ?? $line['BatchNumbers'] ?? [];

                // If Batches is empty (or filtered out by our empty check), try to find one
                if (empty($batches)) {
                    $itemCode = $line['ItemCode'] ?? null;
                    if ($itemCode) {
                        try {
                            $bestBatch = $this->fetchBestBatch($itemCode);
                            if ($bestBatch) {
                                $line['InventoryCountingBatchNumbers'] = [
                                    [
                                        'BatchNumber' => $bestBatch['BatchNumber'],
                                        'Quantity' => $line['CountedQuantity'] ?? 0,
                                        'ExpiryDate' => $bestBatch['ExpiryDate'] ?? null,
                                    ]
                                ];
                                // Ensure we clean up the old key if it existed empty
                                if (isset($line['BatchNumbers']))
                                    unset($line['BatchNumbers']);

                                Log::info("SapImportService: Auto-Enriched Item $itemCode with Batch {$bestBatch['BatchNumber']}");
                            } else {
                                Log::warning("SapImportService: No suitable batch found for Item $itemCode (Expiry > 2026-01-01)");
                            }
                        } catch (\Exception $e) {
                            Log::error("SapImportService: Failed to enrich batch for $itemCode: " . $e->getMessage());
                        }
                    }
                }
            }
        }
    }

    protected function fetchBestBatch($itemCode)
    {
        // Query: SELECT ... FROM ... WHERE ... ItemCode = '$itemCode'
        // Using SQLQueries exposed endpoint
        // Endpoint: SQLQueries('batchesitems')/List?ItemCode='$itemCode'

        $response = $this->sap->get("SQLQueries('batchesitems')/List", [
            'ItemCode' => "'$itemCode'"
        ]);

        $rows = $response['value'] ?? [];

        // Filter: ExpiryDate > 20260101
        $candidates = array_filter($rows, function ($row) {
            $exp = $row['ExpiryDate'] ?? '';
            // Handle null/empty
            if (!$exp)
                return false;
            // Format is YYYYMMDD (e.g. 20271213)
            return $exp > '20260101';
        });

        if (empty($candidates)) {
            return null;
        }

        // Sort by ExpiryDate ASC (Closest date after 2026)
        usort($candidates, function ($a, $b) {
            return strcmp($a['ExpiryDate'], $b['ExpiryDate']);
        });

        return $candidates[0];
    }

    protected function logActivity($resource, $payload, $response, $status)
    {
        try {
            ApiLog::create([
                'user_id' => auth()->id() ?? null,
                'method' => 'POST (Import)',
                'endpoint' => $resource,
                'status_code' => $status,
                'request_payload' => json_encode($payload),
                'response_body' => json_encode($response),
                'database_name' => $this->sap->getCompanyDb(),
                'ip_address' => request()->ip(),
                'user_agent' => request()->userAgent(),
            ]);
        } catch (\Exception $e) {
            // Logging failed, ignore to not break import
        }
    }

    /**
     * Merges multiple flat-mapped rows into a structured document.
     * Handles 2 levels of nesting (Lines -> Batches).
     */
    protected function mergeRowsToDocument(array $rows)
    {
        if (empty($rows))
            return [];

        // 1. Identify Root Fields (Common to all rows, use first row)
        $root = [];
        $firstRow = $rows[0];
        foreach ($firstRow as $key => $val) {
            if (!is_array($val)) {
                $root[$key] = $val;
            }
        }

        // 2. Identify and Group Arrays
        // We look for top-level array keys in the first row structure
        // e.g., 'InventoryCountingLines'
        foreach ($firstRow as $key => $val) {
            if (is_array($val)) {
                // This is a List (e.g. Lines)
                // We need to collect ALL items from ALL rows for this list
                $listKey = $key;
                $mergedList = [];

                // Group By Identifier to merge Sub-Lists (like Batches)
                // If the list item has a unique ID (like ItemCode), use it.
                // Otherwise, treat as separate lines.
                // Heuristic: Look for 'ItemCode' or 'LineNum'

                $groupedItems = [];

                foreach ($rows as $row) {
                    if (!isset($row[$listKey]))
                        continue;

                    // The row might contain a partial item for this list
                    // e.g. row['InventoryCountingLines'] = ['ItemCode' => 'A', 'BatchNumbers' => [...]]
                    // But actually data_set makes it an array of 1 item? 
                    // No, data_set('InventoryCountingLines.ItemCode') creates ['InventoryCountingLines' => ['ItemCode' => 'A']]
                    // It does NOT create an array of items unless we use index 'InventoryCountingLines.0.ItemCode'
                    // BUT our loop above created one structure per row.

                    // So $row[$listKey] is an ASSOCIATIVE array representing the properties of the line found in THIS row.
                    $lineData = $row[$listKey];

                    // Helper to find a grouping key (ItemCode)
                    $groupKey = $lineData['ItemCode'] ?? $lineData['CardCode'] ?? json_encode($lineData);
                    // If we have Batches, we usually have ItemCode.

                    if (!isset($groupedItems[$groupKey])) {
                        $groupedItems[$groupKey] = $lineData;
                        // Initialize nested arrays if any
                        foreach ($lineData as $lk => $lv) {
                            if (is_array($lv)) {
                                // This is a sub-list (e.g. BatchNumbers)
                                // We store it as a collection
                                $groupedItems[$groupKey][$lk] = [$lv];
                                // Wait, $lv is properties of one batch from this row.
                                // We wrap it in [] to start the accumulation.
                            }
                        }
                    } else {
                        // Merge this row's line data into existing line
                        // Mainly to append to sub-lists
                        foreach ($lineData as $lk => $lv) {
                            if (is_array($lv)) {
                                // Append to the sub-list
                                $groupedItems[$groupKey][$lk][] = $lv;
                            } else {
                                // Overwrite or keep? Keep first usually for Headers.
                            }
                        }
                    }
                }


                // Cleanup: Filter empty BatchNumbers/SerialNumbers
                foreach ($groupedItems as &$gItem) {
                    // Pre-calculate CountedQuantity from Batch Mappings if not set
                    if (isset($gItem['BatchNumbers']) && is_array($gItem['BatchNumbers'])) {
                        $sum = 0;
                        foreach ($gItem['BatchNumbers'] as $b) {
                            $sum += (float) ($b['Quantity'] ?? 0);
                        }
                        // Only set if not manually mapped? Or always overwrite?
                        // Usually Auto-Sum is desired if mapping batches.
                        $gItem['CountedQuantity'] = $sum;
                    }

                    if (isset($gItem['BatchNumbers']) && is_array($gItem['BatchNumbers'])) {
                        $gItem['BatchNumbers'] = array_filter($gItem['BatchNumbers'], function ($b) {
                            return !empty($b['BatchNumber']);
                        });
                        // Re-index
                        $gItem['BatchNumbers'] = array_values($gItem['BatchNumbers']);
                        // Remove if empty
                        if (empty($gItem['BatchNumbers'])) {
                            unset($gItem['BatchNumbers']);
                        }
                    }
                    if (isset($gItem['SerialNumbers']) && is_array($gItem['SerialNumbers'])) {
                        $gItem['SerialNumbers'] = array_filter($gItem['SerialNumbers'], function ($s) {
                            return !empty($s['InternalSerialNumber']) || !empty($s['SystemSerialNumber']) || !empty($s['SerialNumber']);
                        });
                        $gItem['SerialNumbers'] = array_values($gItem['SerialNumbers']);
                        if (empty($gItem['SerialNumbers'])) {
                            unset($gItem['SerialNumbers']);
                        }
                    }
                }
                unset($gItem); // break ref

                // Finalize List: flatten keys
                $root[$listKey] = array_values($groupedItems);
            }
        }

        // Special Fix: Move WarehouseCode and UoMCode from Root to Lines if detected
        // Users often map WhsCode/UoMCode as global fields, but SAP InventoryCounting requires them on the Line.
        if (isset($root['InventoryCountingLines']) && is_array($root['InventoryCountingLines'])) {
            $whsCode = $root['WarehouseCode'] ?? $root['WhsCode'] ?? null;
            $uomCode = $root['UoMCode'] ?? $root['UomCode'] ?? null;

            // Iterate all lines to ensure compliance
            foreach ($root['InventoryCountingLines'] as &$line) {
                // 1. Warehouse Code
                if ($whsCode && !isset($line['WarehouseCode'])) {
                    $line['WarehouseCode'] = $whsCode;
                }

                // 2. UoM Code (Critical: Default to 'PC' if missing)
                if (!isset($line['UoMCode'])) {
                    $line['UoMCode'] = $uomCode ?? 'PC';
                }

                // 3. Costing Code (Auto-Assign from WarehouseCode)
                if (isset($line['WarehouseCode']) && !isset($line['CostingCode'])) {
                    $line['CostingCode'] = $line['WarehouseCode'];
                }

                // 4. Set Counted = tYES (Always)
                $line['Counted'] = 'tYES';

                // 3. Rename 'BatchNumbers' to 'InventoryCountingBatchNumbers' for this resource
                if (isset($line['BatchNumbers'])) {
                    $line['InventoryCountingBatchNumbers'] = $line['BatchNumbers'];
                    unset($line['BatchNumbers']);
                }
            }

            // Cleanup specific keys from root
            if (isset($root['WhsCode']))
                unset($root['WhsCode']);
            if (isset($root['UoMCode']))
                unset($root['UoMCode']);
            if (isset($root['UomCode']))
                unset($root['UomCode']);
        }

        return $root;
    }
}
