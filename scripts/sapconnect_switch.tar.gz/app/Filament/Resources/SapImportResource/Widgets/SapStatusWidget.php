<?php

namespace App\Filament\Resources\SapImportResource\Widgets;

use Filament\Widgets\Widget;

class SapStatusWidget extends Widget
{
    protected static string $view = 'filament.resources.sap-import-resource.widgets.sap-status-widget';

    // Ensure full width usage so it doesn't mess up grid too much (though it's fixed pos)
    protected int|string|array $columnSpan = 'full';
}
