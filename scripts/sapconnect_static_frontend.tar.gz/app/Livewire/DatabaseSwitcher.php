<?php

namespace App\Livewire;

use Livewire\Component;
use Filament\Notifications\Notification;

class DatabaseSwitcher extends Component
{
    public $db = 'PPTC_V5_PROD';

    public function render()
    {
        return view('livewire.database-switcher');
    }
}
