<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Automation;
use App\Models\AutomationLog; // Corrected Import
use Illuminate\Support\Facades\Log;

class SyncProducts extends Command
{
    protected $signature = 'sap:sync-products {--code=} {--full}';
    protected $description = 'Sync Products from SAP';

    public function handle()
    {
        $code = $this->option('code');
        $automation = null;
        if ($code) {
            $automation = Automation::where('code', $code)->first();
        } else {
            // Fallback for older automations
            $automation = Automation::where('code', 'sync_products')->first();
        }

        $sapDatabase = $automation ? $automation->sap_database : 'TEST_RETAIL01';

        $this->info("Starting Products Sync for $sapDatabase...");

        if ($automation) {
            $automation->update([
                'last_run_at' => now(),
                'last_run_status' => 'running'
            ]);
        }

        try {
            // Actual Logic Placeholder
            sleep(2); // Simulate work
            $msg = "Products Sync Completed (Placeholder for $sapDatabase).";

            $this->info($msg);

            if ($automation) {
                $automation->update(['last_run_status' => 'success']);
                AutomationLog::create([
                    'automation_id' => $automation->id,
                    'status' => 'success',
                    'message' => $msg,
                ]);
            }
        } catch (\Exception $e) {
            if ($automation) {
                $automation->update(['last_run_status' => 'failed']);
                AutomationLog::create([
                    'automation_id' => $automation->id,
                    'status' => 'failed',
                    'message' => $e->getMessage(),
                ]);
            }
            $this->error($e->getMessage());
        }
    }
}
