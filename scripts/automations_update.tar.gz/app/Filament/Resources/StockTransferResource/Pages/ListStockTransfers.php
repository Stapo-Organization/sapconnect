<?php

namespace App\Filament\Resources\StockTransferResource\Pages;

use App\Filament\Resources\StockTransferResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

use Illuminate\Support\Facades\DB;
use Filament\Notifications\Notification;

class ListStockTransfers extends ListRecords
{
    protected static string $resource = StockTransferResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\Action::make('empty_table')
                ->label('Empty Table (Truncate)')
                ->color('danger')
                ->icon('heroicon-o-trash')
                ->requiresConfirmation()
                ->modalHeading('Empty Stock Transfer Table')
                ->modalDescription('Are you sure you want to delete ALL stock transfers? This action cannot be undone. The system will re-import them on the next run.')
                ->modalSubmitActionLabel('Yes, Empty Table')
                ->action(function () {
                    DB::statement('SET FOREIGN_KEY_CHECKS=0;');
                    DB::table('sap_stock_transfer_lines')->truncate();
                    DB::table('sap_stock_transfers')->truncate();
                    DB::statement('SET FOREIGN_KEY_CHECKS=1;');

                    Notification::make()
                        ->title('Table Emptied Successfully')
                        ->body('All stock transfer records have been deleted.')
                        ->success()
                        ->send();
                }),
            Actions\Action::make('debug_count')
                ->label('Debug DB Count')
                ->color('warning')
                ->action(function () {
                    $count = \App\Models\StockTransfer::count();
                    $prodCount = \App\Models\StockTransfer::where('sap_database', 'PPTC_V5_PROD')->count();
                    $testCount = \App\Models\StockTransfer::where('sap_database', 'TEST_RETAIL01')->count();
                    $logs = \App\Models\AutomationLog::latest()->take(3)->get()->map(fn($l) => "{$l->status}: {$l->message}")->join("\n");

                    Notification::make()
                        ->title('Debug Info')
                        ->body("Total: $count\nProd: $prodCount\nTest: $testCount\n\nLast Logs:\n$logs")
                        ->persistent()
                        ->send();
                }),
        ];
    }
}
