<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Models\ApiTransformer;

class DynamicSapResource extends JsonResource
{
    protected $transformerConfig;

    public function __construct($resource, ApiTransformer $transformerConfig)
    {
        parent::__construct($resource);
        $this->transformerConfig = $transformerConfig;
    }

    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $mapping = $this->transformerConfig->mapping ?? [];
        $result = [];

        foreach ($mapping as $rule) {
            $sourceKey = $rule['source'] ?? null;
            $targetKey = $rule['target'] ?? $sourceKey;
            $type = $rule['type'] ?? 'string';

            if (!$sourceKey)
                continue;

            // Handle Nested properties? Not fully supporting deep dot notation for simplicity unless requested.
            // But we can support basic access.
            $value = $this[$sourceKey] ?? null;

            // Casting
            switch ($type) {
                case 'integer':
                    $value = (int) $value;
                    break;
                case 'float':
                    $value = (float) $value;
                    break;
                case 'boolean':
                    $value = (bool) $value;
                    break;
                case 'array':
                    // If target is array (e.g. ItemPrices), we might just pass it raw
                    // Or ideally we would need nested transformers. 
                    // For now, pass raw array.
                    $value = is_array($value) ? $value : [];
                    break;
            }

            $result[$targetKey] = $value;
        }

        return $result;
    }
}
