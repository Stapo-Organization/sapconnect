<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Models\ApiTransformer;

class DynamicSapResource extends JsonResource
{
    protected $transformerConfig;

    public function __construct($resource, ApiTransformer $transformerConfig)
    {
        parent::__construct($resource);
        $this->transformerConfig = $transformerConfig;
    }

    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $mapping = $this->transformerConfig->mapping ?? [];
        $result = [];

        foreach ($mapping as $rule) {
            $sourceKey = $rule['source'] ?? null;
            $targetKey = $rule['target'] ?? $sourceKey;
            $type = $rule['type'] ?? 'string';

            if (!$sourceKey)
                continue;

            // Handle Nested properties? Not fully supporting deep dot notation for simplicity unless requested.
            // But we can support basic access.
            $value = $this[$sourceKey] ?? null;

            // Casting
            switch ($type) {
                case 'integer':
                    $value = (int) $value;
                    break;
                case 'float':
                    $value = (float) $value;
                    break;
                case 'boolean':
                    $value = (bool) $value;
                    break;
                case 'array':
                    if (isset($rule['sub_mapping']) && is_array($rule['sub_mapping']) && is_array($value)) {
                        $value = collect($value)->map(function ($item) use ($rule) {
                            $mappedItem = [];
                            foreach ($rule['sub_mapping'] as $subRule) {
                                $subSource = $subRule['source'] ?? null;
                                $subTarget = $subRule['target'] ?? $subSource;
                                // Simple type casting for sub-items (only string/int/float supported for now to keep recursion simple)
                                if (!$subSource)
                                    continue;
                                $subVal = $item[$subSource] ?? null;
                                // We could recursively call transform here if we structure it as a method
                                // For now, simple direct mapping
                                $mappedItem[$subTarget] = $subVal;
                            }
                            return $mappedItem;
                        })->toArray();
                    } else {
                        $value = is_array($value) ? $value : [];
                    }
                    break;
            }

            $result[$targetKey] = $value;
        }

        return $result;
    }
}
