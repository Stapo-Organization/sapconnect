<?php

namespace App\Filament\Resources\SmsCampaignResource\Pages;

use App\Filament\Resources\SmsCampaignResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListSmsCampaigns extends ListRecords
{
    protected static string $resource = SmsCampaignResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\Action::make('usage_guide')
                ->label('Usage Guide')
                ->icon('heroicon-o-information-circle')
                ->color('gray')
                ->modalHeading('How to Use SMS Campaigns')
                ->modalContent(new \Illuminate\Support\HtmlString('
                    <div class="prose max-w-none">
                        <h3>1. Create a Campaign</h3>
                        <p>Click <strong>New Sms Campaign</strong> and enter a name and your message template.</p>
                        
                        <h3>2. Message Variables</h3>
                        <p>You can use variables in your message by wrapping the column name in curly braces.</p>
                        <p><strong>Example:</strong> "Hello {Name}, your balance is {Balance}"</p>
                        
                        <h3>3. Uploading Recipients</h3>
                        <p>Upload an Excel or CSV file. The file <strong>MUST</strong> have a header row.</p>
                        <p>The system automatically detects the mobile number if the column is named "Phone", "Mobile", or "Jawwal". Otherwise, it uses the first column.</p>
                        <p><strong>Example Excel Structure:</strong></p>
                        <table class="w-full text-sm border-collapse border border-gray-300">
                            <tr class="bg-gray-100">
                                <th class="border border-gray-300 p-2">Mobile</th>
                                <th class="border border-gray-300 p-2">Name</th>
                                <th class="border border-gray-300 p-2">Balance</th>
                            </tr>
                            <tr>
                                <td class="border border-gray-300 p-2">9665xxxxxxxx</td>
                                <td class="border border-gray-300 p-2">M Ahmed</td>
                                <td class="border border-gray-300 p-2">500</td>
                            </tr>
                        </table>
                        
                        <h3>4. Testing & Sending</h3>
                        <p>After creating the campaign, use the <strong>Test Send</strong> button inside the campaign to send a sample message to yourself.</p>
                        <p>Once satisfied, use <strong>Send to All</strong> to start the campaign.</p>
                    </div>
                '))
                ->modalSubmitAction(false)
                ->modalCancelAction(fn($action) => $action->label('Close')),
            Actions\CreateAction::make(),
        ];
    }
}
