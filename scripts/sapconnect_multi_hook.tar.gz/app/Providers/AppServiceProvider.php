<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        \Dedoc\Scramble\Scramble::afterOpenApiGenerated(function (\Dedoc\Scramble\Support\Generator\OpenApi $openApi) {
            $openApi->secure(
                \Dedoc\Scramble\Support\Generator\SecurityScheme::http('bearer')
            );
        });

        \Filament\Support\Facades\FilamentView::registerRenderHook(
            \Filament\View\PanelsRenderHook::USER_MENU_BEFORE,
            fn(): string => \Illuminate\Support\Facades\Blade::render('@livewire(\'database-switcher\')'),
        );
        \Filament\Support\Facades\FilamentView::registerRenderHook(
            \Filament\View\PanelsRenderHook::SIDEBAR_NAV_START,
            fn(): string => \Illuminate\Support\Facades\Blade::render('@livewire(\'database-switcher\')'),
        );
        \Filament\Support\Facades\FilamentView::registerRenderHook(
            \Filament\View\PanelsRenderHook::BODY_START,
            fn(): string => '<div style="background: red; color: white; padding: 5px; z-index: 99999; position: sticky; top: 0; width: 100%;">DEBUG: AppServiceProvider Loaded</div>',
        );
    }
}
