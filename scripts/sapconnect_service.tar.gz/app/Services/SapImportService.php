<?php

namespace App\Services;

use App\Models\SapImport;
use App\Services\SAP\SapClient;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class SapImportService
{
    protected $sap;

    public function __construct()
    {
        $this->sap = app(SapClient::class);
    }

    public function process(SapImport $import, $filePath)
    {
        // 1. Read CSV
        // For Livewire uploads, filePath might be a temporary path or ID.
        // If it's a string path:
        if (!file_exists($filePath)) {
            // Try storage if it's a relative path
            $filePath = Storage::path($filePath);
        }

        $rows = array_map('str_getcsv', file($filePath));
        $header = array_shift($rows);
        $header = array_map('trim', $header); // clean headers

        $mappedData = [];

        // 2. Transform Rows to Flat Mapped Arrays
        foreach ($rows as $row) {
            if (count($row) !== count($header))
                continue; // Skip malformed
            $rowAssoc = array_combine($header, $row);

            $item = [];
            foreach ($import->mapping as $map) {
                $csvKey = $map['csv_header'];
                $sapKey = $map['sap_field'];

                if (isset($rowAssoc[$csvKey])) {
                    $value = $rowAssoc[$csvKey];
                    // Clean Date? If SAP field contains 'Date'
                    if (str_contains($sapKey, 'Date') && strlen($value) > 10) {
                        $value = substr($value, 0, 10); // 2026-09-14 00... -> 2026-09-14
                    }
                    // Basic Type casting could go here if defined
                    // For now, treat as string or infer
                    if (is_numeric($value)) {
                        $value = strpos($value, '.') !== false ? (float) $value : (int) $value;
                    }

                    data_set($item, $sapKey, $value);
                }
            }
            $mappedData[] = $item;
        }

        // 3. Handle Modes
        if ($import->import_mode === 'Single') {
            $successCount = 0;
            foreach ($mappedData as $payload) {
                $this->sap->post($import->resource, $payload);
                $successCount++;
            }
            return $successCount;
        } elseif ($import->import_mode === 'Document') {
            // Group By Root Keys (to split Multi-Warehouse files)
            $groupedDocs = [];
            foreach ($mappedData as $data) {
                // Extract Root Keys (keys with no dot)
                $rootKeys = [];
                foreach ($data as $k => $v) {
                    if (!is_array($v))
                        $rootKeys[$k] = $v;
                }
                ksort($rootKeys);
                $sig = json_encode($rootKeys);
                $groupedDocs[$sig][] = $data;
            }

            $count = 0;
            foreach ($groupedDocs as $docRows) {
                $payload = $this->mergeRowsToDocument($docRows);

                // MAGIC: Auto-Sum for InventoryCountings
                if (str_contains($import->resource, 'InventoryCountings') && isset($payload['InventoryCountingLines'])) {
                    foreach ($payload['InventoryCountingLines'] as &$line) {
                        // Sum Batch Quantities
                        if (isset($line['BatchNumbers']) && is_array($line['BatchNumbers'])) {
                            $sum = 0;
                            foreach ($line['BatchNumbers'] as $batch) {
                                $sum += ($batch['Quantity'] ?? 0);
                            }
                            // Update CountedQuantity only if not explicitly set greater than 0 (or trust overwrite)
                            // Usually we define Qty -> Batch.Qty. So CountedQuantity is missing or partial.
                            // We should overwrite it.
                            $line['CountedQuantity'] = $sum;
                        }
                    }
                }

                $this->sap->post($import->resource, $payload);
                $count++;
            }

            return $count;
        }

        return 0;
    }

    /**
     * Merges multiple flat-mapped rows into a structured document.
     * Handles 2 levels of nesting (Lines -> Batches).
     */
    protected function mergeRowsToDocument(array $rows)
    {
        if (empty($rows))
            return [];

        // 1. Identify Root Fields (Common to all rows, use first row)
        $root = [];
        $firstRow = $rows[0];
        foreach ($firstRow as $key => $val) {
            if (!is_array($val)) {
                $root[$key] = $val;
            }
        }

        // 2. Identify and Group Arrays
        // We look for top-level array keys in the first row structure
        // e.g., 'InventoryCountingLines'
        foreach ($firstRow as $key => $val) {
            if (is_array($val)) {
                // This is a List (e.g. Lines)
                // We need to collect ALL items from ALL rows for this list
                $listKey = $key;
                $mergedList = [];

                // Group By Identifier to merge Sub-Lists (like Batches)
                // If the list item has a unique ID (like ItemCode), use it.
                // Otherwise, treat as separate lines.
                // Heuristic: Look for 'ItemCode' or 'LineNum'

                $groupedItems = [];

                foreach ($rows as $row) {
                    if (!isset($row[$listKey]))
                        continue;

                    // The row might contain a partial item for this list
                    // e.g. row['InventoryCountingLines'] = ['ItemCode' => 'A', 'BatchNumbers' => [...]]
                    // But actually data_set makes it an array of 1 item? 
                    // No, data_set('InventoryCountingLines.ItemCode') creates ['InventoryCountingLines' => ['ItemCode' => 'A']]
                    // It does NOT create an array of items unless we use index 'InventoryCountingLines.0.ItemCode'
                    // BUT our loop above created one structure per row.

                    // So $row[$listKey] is an ASSOCIATIVE array representing the properties of the line found in THIS row.
                    $lineData = $row[$listKey];

                    // Helper to find a grouping key (ItemCode)
                    $groupKey = $lineData['ItemCode'] ?? $lineData['CardCode'] ?? json_encode($lineData);
                    // If we have Batches, we usually have ItemCode.

                    if (!isset($groupedItems[$groupKey])) {
                        $groupedItems[$groupKey] = $lineData;
                        // Initialize nested arrays if any
                        foreach ($lineData as $lk => $lv) {
                            if (is_array($lv)) {
                                // This is a sub-list (e.g. BatchNumbers)
                                // We store it as a collection
                                $groupedItems[$groupKey][$lk] = [$lv];
                                // Wait, $lv is properties of one batch from this row.
                                // We wrap it in [] to start the accumulation.
                            }
                        }
                    } else {
                        // Merge this row's line data into existing line
                        // Mainly to append to sub-lists
                        foreach ($lineData as $lk => $lv) {
                            if (is_array($lv)) {
                                // Append to the sub-list
                                $groupedItems[$groupKey][$lk][] = $lv;
                            } else {
                                // Overwrite or keep? Keep first usually for Headers.
                            }
                        }
                    }
                }

                // Finalize List: flatten keys
                $root[$listKey] = array_values($groupedItems);
            }
        }

        return $root;
    }
}
