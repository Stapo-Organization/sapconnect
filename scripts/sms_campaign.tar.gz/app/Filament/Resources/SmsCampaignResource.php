<?php

namespace App\Filament\Resources;

use App\Filament\Resources\SmsCampaignResource\Pages;
use App\Models\SmsCampaign;
use App\Services\Sms\CampaignService;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;

class SmsCampaignResource extends Resource
{
    protected static ?string $model = SmsCampaign::class;

    protected static ?string $navigationIcon = 'heroicon-o-chat-bubble-left-right';
    protected static ?string $navigationGroup = 'SMS Management';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('name')
                    ->required()
                    ->maxLength(255),
                Textarea::make('message_body')
                    ->required()
                    ->rows(5)
                    ->helperText('Use {Variable} to insert dynamic data from Excel.'),
                FileUpload::make('file_path')
                    ->required()
                    ->label('Recipient File (Excel/CSV)')
                    ->disk('local')
                    ->directory('sms-campaigns')
                    ->preserveFilenames()
                    ->acceptedFileTypes(['text/csv', 'text/plain', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')->searchable(),
                Tables\Columns\BadgeColumn::make('status')
                    ->colors([
                        'gray' => 'draft',
                        'warning' => 'processing',
                        'success' => 'completed',
                        'danger' => 'failed',
                    ]),
                Tables\Columns\TextColumn::make('total_recipients')->label('Total'),
                Tables\Columns\TextColumn::make('sent_count')->label('Sent'),
                Tables\Columns\TextColumn::make('failed_count')->label('Failed'),
                Tables\Columns\TextColumn::make('created_at')->dateTime()->sortable(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListSmsCampaigns::route('/'),
            'create' => Pages\CreateSmsCampaign::route('/create'),
            'edit' => Pages\EditSmsCampaign::route('/{record}/edit'),
        ];
    }
}
