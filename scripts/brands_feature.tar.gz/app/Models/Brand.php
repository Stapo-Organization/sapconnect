<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;

class Brand extends Model
{
    use HasFactory;

    protected $fillable = [
        'code',
        'name',
        'source',
    ];

    /**
     * Scope a query to only include test environment brands.
     */
    public function scopeTest(Builder $query): void
    {
        $query->where('source', 'test');
    }

    /**
     * Scope a query to only include production environment brands.
     */
    public function scopeProduction(Builder $query): void
    {
        $query->where('source', 'production');
    }
}
