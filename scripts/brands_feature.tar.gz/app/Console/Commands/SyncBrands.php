<?php

namespace App\Console\Commands;

use App\Models\Brand;
use App\Services\SAP\SapClient;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class SyncBrands extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sap:sync-brands';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sync ItemGroups (Brands) from SAP (Test & Production)';

    protected $sap;

    /**
     * Execute the console command.
     */
    public function handle(SapClient $sap)
    {
        $this->sap = $sap;
        $this->info('Starting Brands Sync...');

        $databases = Config::get('sap.databases', []);

        if (empty($databases)) {
            // Fallback to default if no databases defined (though config shows they are)
            $this->syncDatabase(Config::get('sap.company_db'));
        } else {
            foreach ($databases as $dbName => $creds) {
                $this->syncDatabase($dbName);
            }
        }

        $this->info('Brands Sync Completed.');
    }

    protected function syncDatabase($dbName)
    {
        $this->info("Syncing form Database: $dbName");

        try {
            $this->sap->setCompanyDb($dbName);

            // Determine source based on DB Name Convention
            $source = str_contains($dbName, 'PROD') ? 'production' : 'test';

            // Fetch ItemGroups
            // Endpoint: ItemGroups
            // We might need to handle pagination? SAP B1 usually returns 20 by default unless $top is set.
            // Let's set $top to a high number or loop. For now, assuming reasonable number < 1000.
            // Or better, use a loop.

            $nextLink = 'ItemGroups';
            $page = 1;

            do {
                $response = $this->sap->get($nextLink, []);

                $items = $response['value'] ?? [];

                if (empty($items)) {
                    break;
                }

                $this->info("  Fetching page $page... (Count: " . count($items) . ")");

                foreach ($items as $item) {
                    Brand::updateOrCreate(
                        [
                            'code' => $item['Number'],
                            'source' => $source,
                        ],
                        [
                            'name' => $item['GroupName'],
                        ]
                    );
                }

                if (isset($response['odata.nextLink'])) {
                    // Extract relative path if needed, but SAP usually gives relative or absolute.
                    // SapClient::get appends to baseUrl, so we need the relative part.
                    // 'odata.nextLink': "ItemGroups?$skip=20"
                    $nextLink = $response['odata.nextLink'];
                    $page++;
                } else {
                    $nextLink = null;
                }

            } while ($nextLink);

            $this->info("  Database $dbName synced successfully.");

        } catch (\Exception $e) {
            $this->error("  Failed to sync $dbName: " . $e->getMessage());
            Log::error("Brands Sync Failed [$dbName]: " . $e->getMessage());
        }
    }
}
