<?php

namespace App\Services;

use App\Models\StockTransfer;
use App\Models\StockTransferProd;
use App\Models\StockTransferTest;
use App\Models\StockTransferLine;
use App\Services\SAP\SapClient;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class StockTransferService
{
    protected $sap;

    public function __construct(SapClient $sap)
    {
        $this->sap = $sap;
    }

    public function setDatabase($db)
    {
        $this->sap->setCompanyDb($db);
    }

    /**
     * Get the correct model instance based on the active DB
     */
    protected function getModel($activeDb)
    {
        if ($activeDb === 'PPTC_V5_PROD') {
            return new StockTransferProd();
        } elseif ($activeDb === 'TEST_RETAIL01') {
            return new StockTransferTest();
        }

        // Fallback to base model (or throw error?)
        return new StockTransfer();
    }

    public function importFromSap($fullSync = false)
    {
        Log::info("StockTransferService: Starting Import. Full Sync: " . ($fullSync ? 'Yes' : 'No'));

        $activeDb = $this->sap->getCompanyDb();
        $model = $this->getModel($activeDb);
        $table = $model->getTable();

        // Determine Last Sync Date
        $lastUpdate = DB::table($table)->max('update_date');

        // Define Min Date (Fallback or Last Sync)
        if ($lastUpdate && !$fullSync) {
            $minDate = Carbon::parse($lastUpdate)->format('Y-m-d');
            // Optimizing filter to capture NEW (CreationDate) OR UPDATED (UpdateDate) since last sync
            $filter = "CreationDate ge '$minDate' or UpdateDate ge '$minDate'";
        } else {
            // Full Sync or Initial Load: Go back further (e.g. 2015) to ensure all legacy data is caught
            $filter = "CreationDate ge '2015-01-01'";
        }

        $params = [
            '$filter' => $filter,
            '$top' => 100 // Increased from 20 to 100 for performance
        ];

        // Conditional for TEST_RETAIL01
        if ($activeDb === 'TEST_RETAIL01') {
            // Optional override if needed
        }

        $newCount = 0;
        $updatedCount = 0;
        $skippedCount = 0;
        $totalFetched = 0;

        try {
            $skip = 0;
            $top = 100;

            do {
                $params['$skip'] = $skip;
                $params['$top'] = $top;

                // Log::info("StockTransferService: Fetching... Filter: $filter, Skip: $skip");

                $response = $this->sap->get('InventoryTransferRequests', $params);
                $data = $response['value'] ?? [];

                if (!is_array($data) || empty($data))
                    break;

                $pageCount = count($data);
                $totalFetched += $pageCount;

                foreach ($data as $row) {
                    $status = $this->syncStockTransfer($row);
                    if ($status === 'new')
                        $newCount++;
                    elseif ($status === 'updated')
                        $updatedCount++;
                    else
                        $skippedCount++;
                }

                $skip += $pageCount;
            } while ($pageCount > 0);

            Log::info("StockTransferService: Complete (InventoryTransferRequests). New: $newCount, Updated: $updatedCount, Skipped: $skippedCount.");

            return [
                'active_db' => $activeDb,
                'total' => $totalFetched,
                'imported' => $newCount,
                'new' => $newCount,
                'updated' => $updatedCount,
                'skipped' => $skippedCount,
                'sample_date' => $lastUpdate
            ];

        } catch (\Exception $e) {
            Log::error("StockTransferService: Failed: " . $e->getMessage());
            throw $e;
        }
    }

    protected function syncStockTransfer($row)
    {
        $activeDb = $this->sap->getCompanyDb();
        $modelInstance = $this->getModel($activeDb);

        return DB::transaction(function () use ($row, $activeDb, $modelInstance) {
            $docEntry = $row['DocEntry'];

            // Dates from SAP
            $sapUpdateDate = isset($row['UpdateDate']) ? Carbon::parse($row['UpdateDate']) : null;

            // Check existing using the specific model
            $existing = $modelInstance->where('doc_entry', $docEntry)
                // ->where('sap_database', $activeDb) // Redundant if tables are separate, but harmless
                ->first();

            if (!$existing) {
                $this->upsertTransfer($row, $activeDb, $modelInstance);
                return 'new';
            } else {
                $localUpdateDate = $existing->update_date;

                if (!$localUpdateDate || ($sapUpdateDate && $sapUpdateDate->gt($localUpdateDate))) {
                    $this->upsertTransfer($row, $activeDb, $modelInstance, $existing);
                    return 'updated';
                }

                return 'skipped';
            }
        });
    }

    protected function upsertTransfer($row, $database, $modelInstance, $existingModel = null)
    {
        $attributes = [
            'sap_database' => $database,
            'doc_num' => $row['DocNum'],
            'from_warehouse' => $row['FromWarehouse'] ?? null,
            'to_warehouse' => $row['ToWarehouse'] ?? null,
            'doc_date' => isset($row['DocDate']) ? Carbon::parse($row['DocDate'])->format('Y-m-d') : null,
            'document_status' => $row['DocumentStatus'] ?? null,
            'creation_date' => isset($row['CreationDate']) ? Carbon::parse($row['CreationDate']) : null,
            'update_date' => isset($row['UpdateDate']) ? Carbon::parse($row['UpdateDate']) : null,
        ];

        // Calculate total received quantity from lines to determine if it's New
        $linesData = $row['InventoryTransferRequestLines'] ?? $row['StockTransferLines'] ?? [];
        $totalReceived = 0;
        foreach ($linesData as $line) {
            $q = $line['Quantity'] ?? 0;
            $r = $line['RemainingOpenQuantity'] ?? 0;
            $totalReceived += max(0, $q - $r);
        }

        if (isset($row['DocumentStatus'])) {
            if ($row['DocumentStatus'] === 'bost_Close') {
                $attributes['internal_status'] = \App\Models\StockTransfer::STATUS_COMPLETED;
            } elseif ($row['DocumentStatus'] === 'bost_Open' && $totalReceived == 0) {
                $attributes['internal_status'] = \App\Models\StockTransfer::STATUS_NEW;
            }
        }

        if ($existingModel) {
            $existingModel->update($attributes);
            $transfer = $existingModel;
        } else {
            // Ensure doc_entry is part of creation attributes
            $attributes['doc_entry'] = $row['DocEntry'];
            $transfer = $modelInstance->create($attributes);
        }

        // Sync Lines (InventoryTransferRequestLines or StockTransferLines)
        $lines = $row['InventoryTransferRequestLines'] ?? $row['StockTransferLines'] ?? [];
        $this->syncLines($transfer, $lines);
    }

    protected function syncLines($transfer, $lines)
    {
        $currentLines = $transfer->lines()->get();
        $matchedIds = [];

        foreach ($lines as $lineData) {
            $itemCode = $lineData['ItemCode'];

            // Calculate Received Quantity from SAP Data
            $sapQty = $lineData['Quantity'] ?? 0;
            $remainingQty = $lineData['RemainingOpenQuantity'] ?? 0;
            $calculatedReceived = max(0, $sapQty - $remainingQty); // Ensure not negative

            // Intelligent matching: matches ItemCode and tries to preserve ID if possible
            $match = $currentLines->first(function ($l) use ($itemCode, $matchedIds) {
                return $l->item_code === $itemCode && !in_array($l->id, $matchedIds);
            });

            if ($match) {
                $match->update([
                    'item_description' => $lineData['ItemDescription'] ?? $match->item_description,
                    'quantity' => $sapQty,
                    'received_quantity' => $calculatedReceived, // Update based on SAP calculation
                    'from_warehouse_code' => $lineData['FromWarehouseCode'] ?? $match->from_warehouse_code,
                    'warehouse_code' => $lineData['WarehouseCode'] ?? $match->warehouse_code,
                    'line_status' => $lineData['LineStatus'] ?? $match->line_status,
                ]);
                $matchedIds[] = $match->id;
            } else {
                $newLine = $transfer->lines()->create([
                    'item_code' => $itemCode,
                    'item_description' => $lineData['ItemDescription'] ?? null,
                    'quantity' => $sapQty,
                    'received_quantity' => $calculatedReceived,
                    'from_warehouse_code' => $lineData['FromWarehouseCode'] ?? null,
                    'warehouse_code' => $lineData['WarehouseCode'] ?? null,
                    'line_status' => $lineData['LineStatus'] ?? null,
                ]);
                $matchedIds[] = $newLine->id;
            }
        }
        // Cleanup
        $transfer->lines()->whereNotIn('id', $matchedIds)->delete();
    }
}
