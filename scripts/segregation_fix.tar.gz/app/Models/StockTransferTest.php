<?php

namespace App\Models;

class StockTransferTest extends StockTransfer
{
    protected $table = 'sap_stock_transfers_test';

    public function lines()
    {
        return $this->hasMany(StockTransferLineTest::class, 'stock_transfer_id');
    }
}
