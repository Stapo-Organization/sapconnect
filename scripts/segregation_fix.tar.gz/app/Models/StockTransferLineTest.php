<?php

namespace App\Models;

class StockTransferLineTest extends StockTransferLine
{
    protected $table = 'sap_stock_transfer_lines_test';
}
