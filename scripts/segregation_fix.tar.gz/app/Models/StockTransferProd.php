<?php

namespace App\Models;

class StockTransferProd extends StockTransfer
{
    protected $table = 'sap_stock_transfers_prod';

    // Lines relationship must also point to the correct table/model if lines are separated?
    // The migration said: sap_stock_transfer_lines_prod
    // So we need Line models too, or dynamic relationship?
    // Let's create Line models for cleaner approach or just override relations.

    public function lines()
    {
        return $this->hasMany(StockTransferLineProd::class, 'stock_transfer_id');
    }
}
