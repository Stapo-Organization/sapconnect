<?php

namespace App\Models;

class StockTransferLineProd extends StockTransferLine
{
    protected $table = 'sap_stock_transfer_lines_prod';
}
