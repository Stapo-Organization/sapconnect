<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use App\Models\StockTransfer;
use App\Models\StockTransferLine;
use App\Services\SAP\SapClient;

class TruncateStockTransfers extends Command
{
    protected $signature = 'stock:truncate';
    protected $description = 'Truncate Stock Transfer tables (both headers and lines) for the current connection';

    public function handle()
    {
        $sap = app(SapClient::class);
        $db = $sap->getCompanyDb();

        $this->info("Current SAP DB: $db");

        if (!$this->confirm("Are you sure you want to truncate Stock Transfers tables for $db? This cannot be undone.")) {
            $this->info("Operation cancelled.");
            return;
        }

        $headerTable = (new StockTransfer)->getTable();
        $lineTable = (new StockTransferLine)->getTable();

        $this->info("Truncating table: $lineTable");
        DB::table($lineTable)->truncate();

        $this->info("Truncating table: $headerTable");
        DB::table($headerTable)->truncate();

        $this->info("Tables truncated successfully.");
    }
}
