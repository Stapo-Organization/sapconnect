<?php

namespace App\Console\Commands;

use App\Models\Brand;
use App\Models\BrandTest;
use App\Services\SAP\SapClient;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class SyncBrands extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sap:sync-brands';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sync ItemGroups (Brands) from SAP based on active environment.';

    protected $sap;

    /**
     * Execute the console command.
     */
    public function handle(SapClient $sap)
    {
        $this->sap = $sap;

        $activeDb = Config::get('sap.company_db');
        $this->info("Starting Brands Sync for Active Database: $activeDb");

        // Determine Environment/Table
        $isTest = !str_contains($activeDb, 'PROD');

        // OR better: Check which DB it matches in config
        // Actually simplest heuristic: Contains "TEST" or not "PROD"?
        // Let's stick to the heuristic: If it fails to match 'PROD', treat as Test.

        if ($isTest) {
            $this->info("Detected Environment: TEST -> Syncing to 'brands_test' table.");
        } else {
            $this->info("Detected Environment: PRODUCTION -> Syncing to 'brands' table.");
        }

        try {
            // We use the already-configured current session DB (SapClient defaults to this)
            // But ensure we are definitely using the active one.
            $this->sap->setCompanyDb($activeDb);

            $nextLink = 'ItemGroups';
            $page = 1;
            $count = 0;

            do {
                $response = $this->sap->get($nextLink, []);
                $items = $response['value'] ?? [];

                if (empty($items)) {
                    break;
                }

                $this->info("  Fetching page $page... (Count: " . count($items) . ")");

                foreach ($items as $item) {
                    $data = [
                        'code' => $item['Number'],
                        'name' => $item['GroupName'],
                    ];

                    if ($isTest) {
                        BrandTest::updateOrCreate(
                            ['code' => $data['code']],
                            ['name' => $data['name']]
                        );
                    } else {
                        Brand::updateOrCreate(
                            ['code' => $data['code']],
                            ['name' => $data['name']]
                        );
                    }
                    $count++;
                }

                if (isset($response['odata.nextLink'])) {
                    $nextLink = $response['odata.nextLink'];
                    $page++;
                } else {
                    $nextLink = null;
                }

            } while ($nextLink);

            $this->info("Sync Completed. Processed $count records.");

        } catch (\Exception $e) {
            $this->error("Failed to sync: " . $e->getMessage());
            Log::error("Brands Sync Failed [$activeDb]: " . $e->getMessage());
        }
    }
}
