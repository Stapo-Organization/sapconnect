<?php

namespace App\Filament\Resources\BrandTestResource\Pages;

use App\Filament\Resources\BrandTestResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListBrandTests extends ListRecords
{
    protected static string $resource = BrandTestResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
