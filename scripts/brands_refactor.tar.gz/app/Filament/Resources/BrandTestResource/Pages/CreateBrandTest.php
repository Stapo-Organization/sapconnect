<?php

namespace App\Filament\Resources\BrandTestResource\Pages;

use App\Filament\Resources\BrandTestResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBrandTest extends CreateRecord
{
    protected static string $resource = BrandTestResource::class;
}
