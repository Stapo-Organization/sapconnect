<?php

namespace App\Filament\Resources\BrandResource\Pages;

use App\Filament\Resources\BrandResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListBrands extends ListRecords
{
    protected static string $resource = BrandResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
            Actions\Action::make('importFromSap')
                ->label('Import from SAP')
                ->icon('heroicon-o-arrow-down-tray')
                ->color('success')
                ->requiresConfirmation()
                ->action(function () {
                    \Illuminate\Support\Facades\Artisan::call('sap:sync-brands');
                    \Filament\Notifications\Notification::make()
                        ->title('Brands Synced Successfully')
                        ->success()
                        ->send();
                }),
        ];
    }
}
