<?php

namespace App\Filament\Resources\StockTransferResource\Pages;

use App\Filament\Resources\StockTransferResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

use Illuminate\Support\Facades\DB;
use Filament\Notifications\Notification;

class ListStockTransfers extends ListRecords
{
    protected static string $resource = StockTransferResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\Action::make('empty_table')
                ->label('Empty Table (Truncate)')
                ->color('danger')
                ->icon('heroicon-o-trash')
                ->requiresConfirmation()
                ->modalHeading('Empty Stock Transfer Table')
                ->modalDescription('Are you sure you want to delete ALL stock transfers? This action cannot be undone. The system will re-import them on the next run.')
                ->modalSubmitActionLabel('Yes, Empty Table')
                ->action(function () {
                    DB::statement('SET FOREIGN_KEY_CHECKS=0;');

                    $tables = [
                        'sap_stock_transfers',
                        'sap_stock_transfer_lines',
                        'sap_stock_transfers_prod',
                        'sap_stock_transfer_lines_prod',
                        'sap_stock_transfers_test',
                        'sap_stock_transfer_lines_test'
                    ];

                    foreach ($tables as $table) {
                        try {
                            DB::table($table)->truncate();
                        } catch (\Exception $e) {
                            // Ignore missing tables
                        }
                    }

                    DB::statement('SET FOREIGN_KEY_CHECKS=1;');

                    Notification::make()
                        ->title('Table Emptied Successfully')
                        ->body('All stock transfer records (Test & Prod) have been deleted.')
                        ->success()
                        ->send();
                }),
            Actions\Action::make('debug_count')
                ->label('Debug DB Count')
                ->color('warning')
                ->action(function () {
                    $count = \App\Models\StockTransfer::count();
                    $prodCount = \App\Models\StockTransferProd::count();
                    $testCount = \App\Models\StockTransferTest::count();
                    $logs = \App\Models\AutomationLog::latest()->take(3)->get()->map(fn($l) => "{$l->status}: {$l->message}")->join("\n");

                    Notification::make()
                        ->title('Debug Info')
                        ->body("Legacy: $count\nProd: $prodCount\nTest: $testCount\n\nLast Logs:\n$logs")
                        ->persistent()
                        ->send();
                }),
        ];
    }
}
