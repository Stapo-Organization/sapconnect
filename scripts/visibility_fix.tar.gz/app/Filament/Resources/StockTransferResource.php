<?php

namespace App\Filament\Resources;

use App\Filament\Resources\StockTransferResource\Pages;
use App\Models\StockTransfer;
use App\Models\StockTransferLine;
use App\Services\StockTransferService;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Filament\Notifications\Notification;

class StockTransferResource extends Resource
{
    protected static ?string $model = StockTransfer::class;

    protected static ?string $navigationIcon = 'heroicon-o-truck';

    protected static ?string $navigationLabel = 'Inventory Transfer Requests';

    protected static ?string $navigationGroup = 'SAP Management';

    public static function getEloquentQuery(): Builder
    {
        $db = session('sap_company_db', config('sap.company_db'));

        if ($db === 'PPTC_V5_PROD') {
            return \App\Models\StockTransferProd::query();
        } elseif ($db === 'TEST_RETAIL01') {
            return \App\Models\StockTransferTest::query();
        }

        return parent::getEloquentQuery();
    }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('Transfer Details')
                    ->columns(2)
                    ->schema([
                        Forms\Components\TextInput::make('doc_num')
                            ->label('Document Number')
                            ->disabled(),
                        Forms\Components\TextInput::make('document_status')
                            ->label('SAP Status')
                            ->disabled(),
                        Forms\Components\TextInput::make('internal_status')
                            ->label('Internal Status')
                            ->disabled(),
                        Forms\Components\TextInput::make('from_warehouse')
                            ->label('From Warehouse')
                            ->disabled(),
                        Forms\Components\TextInput::make('to_warehouse')
                            ->label('To Warehouse')
                            ->disabled(),
                        Forms\Components\DatePicker::make('doc_date')
                            ->label('Document Date')
                            ->disabled(),
                    ]),

                Forms\Components\Section::make('Items')
                    ->schema([
                        Forms\Components\Repeater::make('lines')
                            ->relationship()
                            ->schema([
                                Forms\Components\Grid::make(4)
                                    ->schema([
                                        Forms\Components\TextInput::make('item_code')
                                            ->label('Item Code')
                                            ->disabled(),
                                        Forms\Components\TextInput::make('item_description')
                                            ->label('Description')
                                            ->disabled(),
                                        Forms\Components\TextInput::make('quantity')
                                            ->label('SAP Sent Quantity')
                                            ->numeric()
                                            ->disabled(),
                                        Forms\Components\TextInput::make('line_status')
                                            ->label('Line Status')
                                            ->disabled(),
                                        Forms\Components\TextInput::make('received_quantity')
                                            ->label('SAP Received Quantity')
                                            ->numeric()
                                            ->disabled(),

                                        // New Fields
                                        Forms\Components\TextInput::make('sent_quantity')
                                            ->label('Sent Quantity')
                                            ->numeric()
                                            ->default(0)
                                            ->minValue(0)
                                            // Editable only by Sender when Status is New
                                            ->disabled(function ($record, $livewire) {
                                                // Check header status via livewire or record relation?
                                                // Repeater items context is tricky. Using record context (Line)
                                                // We need access to parent header internal_status.
                                                // Generally better to handle this via bulk actions or dedicated UI, 
                                                // but for inline edit:
                                                return false; // logic to be refined in actions
                                            }),

                                        Forms\Components\TextInput::make('actual_received_quantity')
                                            ->label('Actual Received Quantity')
                                            ->numeric()
                                            ->default(0)
                                            ->minValue(0)
                                            ->disabled(function () {
                                                return false; // logic to be refined
                                            }),
                                    ]),
                            ])
                            ->addable(false)
                            ->deletable(false)
                            ->columnSpanFull(),
                    ]),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('doc_num')->label('Doc Num')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('from_warehouse')->label('From')->searchable(),
                Tables\Columns\TextColumn::make('to_warehouse')->label('To')->searchable(),
                Tables\Columns\TextColumn::make('doc_date')->label('Date')->date()->sortable(),
                Tables\Columns\TextColumn::make('document_status')->label('SAP Status')
                    ->badge()
                    ->colors([
                        'success' => 'O', // Open?
                        'danger' => 'C', // Closed?
                    ]),
                Tables\Columns\TextColumn::make('internal_status')
                    ->label('Internal Status')
                    ->badge()
                    ->colors([
                        'gray' => \App\Models\StockTransfer::STATUS_NEW,
                        'warning' => \App\Models\StockTransfer::STATUS_SHIPPED,
                        'info' => \App\Models\StockTransfer::STATUS_RECEIVED,
                        'success' => \App\Models\StockTransfer::STATUS_COMPLETED,
                    ]),
                Tables\Columns\TextColumn::make('created_at')->dateTime()->sortable()->toggleable(isToggledHiddenByDefault: true),

                // SAP/Base Sent Quantity
                Tables\Columns\TextColumn::make('sap_sent_quantity')
                    ->label('SAP Sent Qty')
                    ->state(function (StockTransfer $record): string {
                        return (string) $record->lines->sum('quantity');
                    }),

                // Sent Quantity (Internal)
                Tables\Columns\TextColumn::make('sent_quantity')
                    ->label('Sent Qty')
                    ->state(function (StockTransfer $record): string {
                        $total = $record->lines->sum('quantity');
                        $sent = $record->lines->sum('sent_quantity');
                        $pct = $total > 0 ? round(($sent / $total) * 100) : 0;
                        return "{$sent} ({$pct}%)";
                    }),

                // SAP Received Quantity
                Tables\Columns\TextColumn::make('sap_received_quantity')
                    ->label('SAP Received Qty')
                    ->state(function (StockTransfer $record): string {
                        $total = $record->lines->sum('quantity');
                        $received = $record->lines->sum('received_quantity');
                        $pct = $total > 0 ? round(($received / $total) * 100) : 0;
                        return "{$received} ({$pct}%)";
                    }),

                // Actual Received Quantity (Internal)
                Tables\Columns\TextColumn::make('actual_received_quantity')
                    ->label('Actual Received Qty')
                    ->state(function (StockTransfer $record): string {
                        $total = $record->lines->sum('quantity');
                        $actual = $record->lines->sum('actual_received_quantity');
                        $pct = $total > 0 ? round(($actual / $total) * 100) : 0;
                        return "{$actual} ({$pct}%)";
                    }),
            ])
            ->filters([
                // From Warehouse Filter
                Tables\Filters\SelectFilter::make('from_warehouse')
                    ->label('From Warehouse')
                    ->options(\App\Models\Warehouse::pluck('warehouse_name', 'warehouse_code'))
                    ->searchable(),

                // To Warehouse Filter
                Tables\Filters\SelectFilter::make('to_warehouse')
                    ->label('To Warehouse')
                    ->options(\App\Models\Warehouse::pluck('warehouse_name', 'warehouse_code'))
                    ->searchable(),

                // Document Date Filter
                Tables\Filters\Filter::make('doc_date')
                    ->form([
                        Forms\Components\DatePicker::make('date_from')->label('Date From'),
                        Forms\Components\DatePicker::make('date_to')->label('Date To'),
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query
                            ->when(
                                $data['date_from'],
                                fn(Builder $query, $date) => $query->whereDate('doc_date', '>=', $date)
                            )
                            ->when(
                                $data['date_to'],
                                fn(Builder $query, $date) => $query->whereDate('doc_date', '<=', $date)
                            );
                    }),

                // SAP Status Filter
                Tables\Filters\SelectFilter::make('document_status')
                    ->label('SAP Status')
                    ->options([
                        'O' => 'Open',
                        'C' => 'Closed',
                    ]),

                // Internal Status Filter
                Tables\Filters\SelectFilter::make('internal_status')
                    ->label('Internal Status')
                    ->options([
                        \App\Models\StockTransfer::STATUS_NEW => 'New',
                        \App\Models\StockTransfer::STATUS_SHIPPED => 'Shipped',
                        \App\Models\StockTransfer::STATUS_RECEIVED => 'Received',
                        \App\Models\StockTransfer::STATUS_COMPLETED => 'Completed',
                    ]),

                // SAP Received Qty Filter
                Tables\Filters\Filter::make('sap_received_qty')
                    ->form([
                        Forms\Components\TextInput::make('min_qty')->numeric()->label('Min Received Qty'),
                        Forms\Components\TextInput::make('max_qty')->numeric()->label('Max Received Qty'),
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        $lineTable = (new StockTransferLine)->getTable();
                        $headerTable = (new StockTransfer)->getTable();
                        return $query
                            ->when(
                                $data['min_qty'],
                                fn(Builder $query, $qty) => $query->whereRaw("(SELECT SUM(received_quantity) FROM $lineTable WHERE stock_transfer_id = $headerTable.id) >= ?", [$qty])
                            )
                            ->when(
                                $data['max_qty'],
                                fn(Builder $query, $qty) => $query->whereRaw("(SELECT SUM(received_quantity) FROM $lineTable WHERE stock_transfer_id = $headerTable.id) <= ?", [$qty])
                            );
                    }),

                // Received Percentage Filter
                Tables\Filters\Filter::make('received_progress')
                    ->form([
                        Forms\Components\TextInput::make('min_pct')->numeric()->label('Min %')->suffix('%'),
                        Forms\Components\TextInput::make('max_pct')->numeric()->label('Max %')->suffix('%'),
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        $lineTable = (new StockTransferLine)->getTable();
                        $headerTable = (new StockTransfer)->getTable();
                        // Formula: (SUM(received_quantity) / NULLIF(SUM(quantity), 0)) * 100
                        $subquery = "(SELECT (SUM(received_quantity) / NULLIF(SUM(quantity), 0)) * 100 FROM $lineTable WHERE stock_transfer_id = $headerTable.id)";

                        return $query
                            ->when(
                                $data['min_pct'],
                                fn(Builder $query, $pct) => $query->whereRaw("$subquery >= ?", [$pct])
                            )
                            ->when(
                                $data['max_pct'],
                                fn(Builder $query, $pct) => $query->whereRaw("$subquery <= ?", [$pct])
                            );
                    }),
            ])
            ->headerActions([
                Tables\Actions\Action::make('import_from_sap')
                    ->label('Import from SAP')
                    ->icon('heroicon-o-arrow-down-tray')
                    ->action(function () {
                        try {
                            $service = app(StockTransferService::class);
                            $result = $service->importFromSap();

                            // Handle legacy return (int) if deploy is partial, but we expect array now
                            if (is_int($result)) {
                                $msg = "Imported $result records.";
                            } else {
                                $msg = "Sync Complete.\nNew: {$result['new']}\nUpdated: {$result['updated']}\nSkipped: {$result['skipped']}";

                                // SMS Notification Logic
                                if ($result['new'] > 0 || $result['updated'] > 0) {
                                    $smsMsg = "Stock Transfer Import:\nNew: {$result['new']}, Updated: {$result['updated']}.";

                                    $recipients = \App\Models\User::where('receive_sms_on_stock_transfer_import', true)
                                        ->whereNotNull('mobile_number')
                                        ->pluck('mobile_number')
                                        ->toArray();

                                    if (!empty($recipients)) {
                                        $smsService = new \App\Services\SMS\TaqnyatService();
                                        $smsService->sendSms($recipients, $smsMsg);
                                    }
                                }
                            }

                            Notification::make()
                                ->title('Import Result')
                                ->body($msg)
                                ->success()
                                ->persistent() // Keep it visible for debugging
                                ->send();
                        } catch (\Exception $e) {
                            Notification::make()
                                ->title('Import Failed')
                                ->body($e->getMessage())
                                ->danger()
                                ->send();
                        }
                    }),
            ])
            ->actions([
                Tables\Actions\EditAction::make()
                    ->label('Manage')
                    ->visible(function (StockTransfer $record) {
                        $user = auth()->user();
                        // If user has a warehouse code, they can only receive if they are the recipient
                        if ($user && $user->warehouse_code) {
                            return $record->to_warehouse === $user->warehouse_code;
                        }
                        return true; // Admins or no-warehouse users can inspect/edit
                    }),
            ])
            ->bulkActions([
                //
            ])
            ->modifyQueryUsing(function (Builder $query) {
                $user = auth()->user();
                if ($user && $user->warehouse_code) {
                    // Show transfers where the user is either the sender OR the receiver
                    $query->where(function ($q) use ($user) {
                        $q->where('from_warehouse', $user->warehouse_code)
                            ->orWhere('to_warehouse', $user->warehouse_code);
                    });
                }
                return $query->with('lines');
            });
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListStockTransfers::route('/'),
            'create' => Pages\CreateStockTransfer::route('/create'), // Not really used
            'edit' => Pages\EditStockTransfer::route('/{record}/edit'),
        ];
    }
}
