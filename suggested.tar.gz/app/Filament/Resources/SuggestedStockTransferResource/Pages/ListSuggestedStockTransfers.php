<?php

namespace App\Filament\Resources\SuggestedStockTransferResource\Pages;

use App\Filament\Resources\SuggestedStockTransferResource;
use Filament\Resources\Pages\ListRecords;
use Filament\Actions\Action;
use Filament\Notifications\Notification;
use App\Jobs\CalculateStockOpportunitiesJob;

class ListSuggestedStockTransfers extends ListRecords
{
    protected static string $resource = SuggestedStockTransferResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Action::make('calculate_now')
                ->label('تشغيل المحرك الذكي للاقتراحات')
                ->icon('heroicon-o-sparkles')
                ->color('warning')
                ->requiresConfirmation()
                ->action(function () {
                    CalculateStockOpportunitiesJob::dispatchSync();
                    Notification::make()
                        ->title('استخراج الفرص تم بنجاح')
                        ->success()
                        ->send();
                }),
        ];
    }
}
