<?php

namespace App\Filament\RetailWidgets;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;
use Filament\Widgets\Concerns\InteractsWithPageFilters;
use App\Models\Warehouse;
use App\Models\SapInvoice;
use Carbon\Carbon;

class StoreSalesWidget extends BaseWidget
{
    use InteractsWithPageFilters;

    protected static ?string $pollingInterval = '30s';

    protected function getStats(): array
    {
        $startDate = $this->filters['startDate'] ?? Carbon::today()->toDateString();
        $endDate = $this->filters['endDate'] ?? Carbon::today()->toDateString();

        $startDate = Carbon::parse($startDate)->startOfDay();
        $endDate = Carbon::parse($endDate)->endOfDay();

        $stores = Warehouse::whereNotNull('sales_employee_code')
            ->where('sales_employee_code', '!=', '')
            ->get();

        $cardCode = 'C000001';

        $stats = [];

        foreach ($stores as $store) {
            $totalSales = SapInvoice::where('sales_employee_code', $store->sales_employee_code)
                ->where('card_code', $cardCode)
                ->whereBetween('doc_date', [$startDate, $endDate])
                ->sum('doc_total');

            $stats[] = Stat::make($store->warehouse_name ?: $store->warehouse_code, number_format($totalSales, 2) . ' SAR')
                ->description("Sales for " . $store->warehouse_code)
                ->descriptionIcon('heroicon-m-currency-dollar')
                ->color($totalSales > 0 ? 'success' : 'gray');
        }

        return $stats;
    }
}
