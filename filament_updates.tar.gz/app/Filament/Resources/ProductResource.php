<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ProductResource\Pages;
use App\Models\Product;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class ProductResource extends Resource
{
    public static function canViewAny(): bool
    {
        return !auth()->user()->hasRole('Branch Manager');
    }

    protected static ?string $model = Product::class;

    protected static ?string $navigationIcon = 'heroicon-o-cube';

    public static function getNavigationLabel(): string
    {
        return __('Products');
    }

    public static function getModelLabel(): string
    {
        return __('Product');
    }

    public static function getPluralModelLabel(): string
    {
        return __('Products');
    }

    public static function getNavigationGroup(): ?string
    {
        return __('Master Data');
    }

    protected static ?int $navigationSort = 2; // After Brands (which is likely 1)

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('item_code')
                    ->label(__('Item Code'))
                    ->required()
                    ->maxLength(255),
                Forms\Components\TextInput::make('item_name')
                    ->label(__('Item Name'))
                    ->maxLength(255),
                Forms\Components\TextInput::make('foreign_name')
                    ->label(__('Foreign Name'))
                    ->maxLength(255),
                Forms\Components\TextInput::make('items_group_code')
                    ->label(__('Items Group Code'))
                    ->numeric(),
                Forms\Components\TextInput::make('inventory_uom')
                    ->label(__('Inventory UOM'))
                    ->maxLength(255),
                Forms\Components\TextInput::make('piece_barcode')
                    ->label(__('Piece Barcode'))
                    ->maxLength(255),
                Forms\Components\TextInput::make('sales_items_per_unit')
                    ->label(__('Sales Items Per Unit'))
                    ->numeric(),
                Forms\Components\DateTimePicker::make('create_date')
                    ->label(__('Create Date'))
                    ->disabled(),
                Forms\Components\DateTimePicker::make('update_date')
                    ->label(__('Update Date'))
                    ->disabled(),
                Forms\Components\Select::make('source')
                    ->label(__('Source'))
                    ->options([
                        'test' => __('Test Environment'),
                        'production' => __('Production'),
                    ])
                    ->required(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(function (Builder $query) {
                // Determine current DB from session or config
                $currentDb = session('sap_company_db', config('sap.company_db'));
                $source = ($currentDb === 'PPTC_V5_PROD') ? 'production' : 'test';

                return $query->where('source', $source);
            })
            ->columns([
                Tables\Columns\ImageColumn::make('product_image')
                    ->label(__('Image'))
                    ->alignCenter()
                    ->state(function (Product $record) {
                        $code = $record->item_code;
                        if (empty($code))
                            return null;
                        $folder = substr($code, 0, 4);
                        return "https://ppte.sa/img/{$folder}/{$code}.png";
                    })
                    ->url(fn($state) => $state)
                    ->openUrlInNewTab(),
                Tables\Columns\TextColumn::make('item_code')
                    ->label(__('Item Code'))
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('item_name')
                    ->label(__('Item Name'))
                    ->searchable(),
                Tables\Columns\TextColumn::make('foreign_name')
                    ->label(__('Foreign Name'))
                    ->searchable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('items_group_code')
                    ->label(__('Items Group Code'))
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('inventory_uom')
                    ->label(__('Inventory UOM'))
                    ->searchable()
                    ->toggleable(),
                Tables\Columns\TextColumn::make('piece_barcode')
                    ->label(__('Piece Barcode'))
                    ->searchable(),
                Tables\Columns\TextColumn::make('sales_items_per_unit')
                    ->label(__('Sales Items Per Unit')),
                Tables\Columns\TextColumn::make('create_date')
                    ->label(__('Create Date'))
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('update_date')
                    ->label(__('Update Date'))
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\BadgeColumn::make('source')
                    ->label(__('Source'))
                    ->colors([
                        'warning' => 'test',
                        'success' => 'production',
                    ]),
                Tables\Columns\TextColumn::make('created_at')
                    ->label(__('Created At'))
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('source')
                    ->label(__('Source'))
                    ->options([
                        'test' => __('Test Environment'),
                        'production' => __('Production'),
                    ]),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListProducts::route('/'),
            'create' => Pages\CreateProduct::route('/create'),
            'edit' => Pages\EditProduct::route('/{record}/edit'),
        ];
    }
}
