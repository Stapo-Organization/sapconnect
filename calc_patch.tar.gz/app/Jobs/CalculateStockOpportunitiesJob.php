<?php

namespace App\Jobs;

use App\Models\SuggestedStockTransfer;
use App\Models\Warehouse;
use App\Services\SAP\SapClient;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CalculateStockOpportunitiesJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 3600;

    public function handle(SapClient $sapClient): void
    {
        try {
            // Target Production DB explicitly
            $sapClient->setCompanyDb('PPTC_V5_PROD');

            // 1. Fetch local average daily sales FIRST to find active items
            // Filter strictly to last 90 days of PROD active sales
            $salesData = DB::table('sap_invoice_lines')
                ->join('sap_invoices', 'sap_invoice_lines.sap_invoice_id', '=', 'sap_invoices.id')
                ->leftJoin('warehouses', 'sap_invoices.sales_employee_code', '=', 'warehouses.sales_employee_code')
                ->select(
                    'sap_invoice_lines.item_code',
                    DB::raw('COALESCE(warehouses.warehouse_code, sap_invoice_lines.warehouse_code) as warehouse_code'),
                    DB::raw('SUM(sap_invoice_lines.quantity) / 90 as ads')
                )
                ->whereDate('sap_invoices.doc_date', '>=', now()->subDays(90)->toDateString())
                ->groupBy('sap_invoice_lines.item_code', 'warehouse_code')
                ->get()
                ->groupBy('item_code');

            $activeItemCodes = $salesData->keys()->filter()->toArray();
            // 2. Fetch Stock completely locally from our pre-synced table (Instantaneous!)
            // We NO LONGER ping SAP because `sap:sync-recent-stock` maintains our data independently.
            $currentStock = [];
            if (!empty($activeItemCodes)) {
                $stockRecords = \App\Models\WarehouseItemStock::whereIn('item_code', $activeItemCodes)->get();
                foreach($stockRecords as $stock) {
                    $currentStock[$stock->item_code][$stock->warehouse_code] = $stock->in_stock;
                }
            }

            $warehouses = Warehouse::pluck('warehouse_code')->toArray();
            
            DB::beginTransaction();
            // Delete old pending suggestions
            SuggestedStockTransfer::where('status', 'pending')->delete();

            foreach ($currentStock as $itemCode => $whsStock) {
                $itemSales = $salesData->get($itemCode)?->keyBy('warehouse_code') ?? collect();
                
                $slowMoving = [];
                $highDemand = [];

                foreach ($whsStock as $whsCode => $stock) {
                    // Only process our explicitly watched warehouses, or fallback to any generic mappings if requested
                    if (!in_array($whsCode, $warehouses)) continue;

                    $ads = $itemSales->get($whsCode)->ads ?? 0;
                    $dos = $ads > 0 ? $stock / $ads : 999;
                    
                    // Production Formula: Dos > 90 days, substantial stock (>10), very slow moving
                    if ($dos > 90 && $stock > 10 && $ads < 0.1) {
                        $slowMoving[] = [
                            'warehouse' => $whsCode,
                            'stock' => $stock,
                            'ads' => $ads,
                            'dos' => $dos
                        ];
                    }

                    // Production Formula: Dos < 7 (1 week left), good demand
                    if ($dos < 7 && $ads > 0.5) {
                        $highDemand[] = [
                            'warehouse' => $whsCode,
                            'stock' => $stock,
                            'ads' => $ads,
                            'dos' => $dos
                        ];
                    }
                }

                foreach ($highDemand as $target) {
                    foreach ($slowMoving as &$source) {
                        if ($source['stock'] <= 10) continue; 
                        
                        $requiredQty = ($target['ads'] * 30) - $target['stock'];
                        $availableQty = $source['stock'] - ($source['ads'] * 30);

                        if ($requiredQty > 0 && $availableQty > 0) {
                            $suggestedQty = min($requiredQty, $availableQty);
                            
                            if ($suggestedQty > 0) {
                                SuggestedStockTransfer::create([
                                    'item_code' => $itemCode,
                                    'source_warehouse' => $source['warehouse'],
                                    'target_warehouse' => $target['warehouse'],
                                    'suggested_quantity' => $suggestedQty,
                                    'source_ads' => $source['ads'],
                                    'source_stock' => $source['stock'],
                                    'target_ads' => $target['ads'],
                                    'target_stock' => $target['stock'],
                                ]);
                                
                                $source['stock'] -= $suggestedQty;
                                $target['stock'] += $suggestedQty;
                                break;
                            }
                        }
                    }
                }
            }
            DB::commit();

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error("CalculateStockOpportunitiesJob Failed: " . $e->getMessage());
            throw $e;
        }
    }
}
