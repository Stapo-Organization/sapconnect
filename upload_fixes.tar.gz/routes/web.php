<?php

use Illuminate\Support\Facades\Route;

Route::redirect('/developer/docs', '/docs/api');
Route::get('/', function () {
    return redirect('/admin');
});

Route::get('/test-lang', function () {
    app()->setLocale('ar');
    return [
        'locale' => app()->getLocale(),
        'lang_path' => lang_path(),
        'ar_json_exists' => file_exists(lang_path('ar.json')),
        'users_translation' => __('Users'),
        'system_settings' => __('System Settings'),
        'json_error' => json_last_error_msg(),
    ];
});

