<?php

namespace App\Filament\RetailWidgets;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;
use Filament\Widgets\Concerns\InteractsWithPageFilters;
use App\Models\Warehouse;
use App\Models\SapInvoice;
use Carbon\Carbon;

class StoreSalesWidget extends BaseWidget
{
    use InteractsWithPageFilters;

    protected static ?string $pollingInterval = '30s';

    protected function getStats(): array
    {
        $startDate = $this->filters['startDate'] ?? Carbon::today()->toDateString();
        $endDate = $this->filters['endDate'] ?? Carbon::today()->toDateString();

        $startDate = Carbon::parse($startDate)->startOfDay();
        $endDate = Carbon::parse($endDate)->endOfDay();

        $cardCode = 'C0000001';

        // Get all retail invoices in date range grouped by employee code
        $invoicesByEmp = SapInvoice::where('card_code', $cardCode)
            ->whereBetween('doc_date', [$startDate, $endDate])
            ->select('sales_employee_code', \Illuminate\Support\Facades\DB::raw('SUM(doc_total) as total'))
            ->groupBy('sales_employee_code')
            ->get();

        $stats = [];
        $employeeCodes = $invoicesByEmp->pluck('sales_employee_code')->filter()->toArray();

        // Get any mapped warehouses if they exist
        $stores = Warehouse::whereIn('sales_employee_code', $employeeCodes)->get()->keyBy('sales_employee_code');

        foreach ($invoicesByEmp as $row) {
            $code = $row->sales_employee_code;
            $totalSales = $row->total;

            if (!$code) continue; // skip null entries

            $storeName = "Sales Employee: " . $code;
            if ($stores->has($code)) {
                $storeName = $stores->get($code)->warehouse_name ?: $stores->get($code)->warehouse_code;
            }

            $stats[] = Stat::make($storeName, number_format($totalSales, 2) . ' SAR')
                ->description("Retail Sales")
                ->descriptionIcon('heroicon-m-currency-dollar')
                ->color($totalSales > 0 ? 'success' : 'gray');
        }

        // Sort stats descending by sales
        usort($stats, function($a, $b) {
            // Helper to extract float from formatted string "27,976.69 SAR" is too tricky, better to just let it be unsorted or we just return it
            return 0;
        });

        // Fallback for sorting: Sort $invoicesByEmp by total desc before looping!
        // Actually it's already generated. Let's just return it.
        return $stats;
    }
}
