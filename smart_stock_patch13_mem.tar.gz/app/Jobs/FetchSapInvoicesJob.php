<?php

namespace App\Jobs;

use App\Models\SapInvoice;
use App\Models\SapInvoiceLine;
use App\Services\SAP\SapClient;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class FetchSapInvoicesJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 3600; // 1 hour

    public function handle(SapClient $sapClient): void
    {
        ini_set('memory_limit', '2048M');
        DB::disableQueryLog();

        $limit = 500;
        $skip = 0;

        try {
            // Target Production DB explicitly
            $sapClient->setCompanyDb('PPTC_V5_PROD');

            // Clear test data safely
            DB::statement('SET FOREIGN_KEY_CHECKS=0;');
            \App\Models\SapInvoiceLine::truncate();
            \App\Models\SapInvoice::truncate();
            DB::statement('SET FOREIGN_KEY_CHECKS=1;');

            $totalFetched = 0;
            
            while (true) {
                $response = $sapClient->get('Invoices', [
                    '$filter' => "DocDate ge '2026-01-01'",
                    '$top' => 50,
                    '$skip' => $totalFetched,
                    '$orderby' => 'DocEntry desc',
                ]);

                $invoices = $response['value'] ?? [];
                
                if (empty($invoices)) {
                    break;
                }
                
                $fetchedCount = count($invoices);
                Log::info("FetchSapInvoicesJob: Fetched " . $fetchedCount . " invoices from SAP.");

            if (!empty($invoices)) {
                DB::beginTransaction();
                foreach ($invoices as $inv) {
                    $sapInvoice = SapInvoice::updateOrCreate(
                        ['doc_num' => $inv['DocNum']],
                        [
                            'card_code' => $inv['CardCode'] ?? null,
                            'doc_date' => $inv['DocDate'] ?? null,
                            'sales_employee_code' => $inv['SalesPersonCode'] ?? null,
                            'doc_total' => $inv['DocTotal'] ?? 0,
                        ]
                    );

                    if (isset($inv['DocumentLines']) && is_array($inv['DocumentLines'])) {
                        foreach ($inv['DocumentLines'] as $line) {
                            if (!empty($line['ItemCode'])) {
                                SapInvoiceLine::updateOrCreate(
                                    [
                                        'sap_invoice_id' => $sapInvoice->id,
                                        'item_code' => $line['ItemCode'],
                                        'warehouse_code' => $line['WarehouseCode'] ?? null,
                                    ],
                                    [
                                        'quantity' => $line['Quantity'] ?? 0,
                                    ]
                                );
                            }
                        }
                    }
                }
                DB::commit();
            }
            
            $totalFetched += $fetchedCount;
            unset($invoices, $response);
            gc_collect_cycles();
        } // end while
    } catch (\Exception $e) {
            DB::rollBack();
            Log::error("FetchSapInvoicesJob Failed: " . $e->getMessage());
        }
    }
}
