<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Brand;
use Illuminate\Http\Request;

class StoreController extends Controller
{
    /**
     * Get all brands.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function getBrands(Request $request)
    {
        // Limit or paginate if needed. For now, get all.
        // Also order by code or name for consistency.
        $brands = Brand::orderBy('name')->get();

        return response()->json([
            'status' => 'success',
            'data' => $brands
        ]);
    }
}
