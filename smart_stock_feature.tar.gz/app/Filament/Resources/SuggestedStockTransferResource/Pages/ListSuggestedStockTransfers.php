<?php

namespace App\Filament\Resources\SuggestedStockTransferResource\Pages;

use App\Filament\Resources\SuggestedStockTransferResource;
use Filament\Resources\Pages\ListRecords;
use Filament\Actions\Action;
use Filament\Notifications\Notification;
use App\Jobs\CalculateStockOpportunitiesJob;
use App\Jobs\FetchSapInvoicesJob;

class ListSuggestedStockTransfers extends ListRecords
{
    protected static string $resource = SuggestedStockTransferResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Action::make('sync_invoices')
                ->label('1. مزامنة أحدث الفواتير')
                ->icon('heroicon-o-cloud-arrow-down')
                ->color('info')
                ->requiresConfirmation()
                ->action(function () {
                    FetchSapInvoicesJob::dispatch();
                    Notification::make()
                        ->title('تم بدء مزامنة הפواتير في الخلفية')
                        ->success()
                        ->send();
                }),
                
            Action::make('calculate_now')
                ->label('2. تشغيل المحرك الذكي للاقتراحات')
                ->icon('heroicon-o-sparkles')
                ->color('warning')
                ->requiresConfirmation()
                ->action(function () {
                    CalculateStockOpportunitiesJob::dispatch();
                    Notification::make()
                        ->title('جاري تحليل ملايين البيانات واكتشاف الفرص في الخلفية')
                        ->success()
                        ->send();
                }),
        ];
    }
}
