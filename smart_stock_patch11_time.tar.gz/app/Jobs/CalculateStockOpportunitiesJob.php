<?php

namespace App\Jobs;

use App\Models\SuggestedStockTransfer;
use App\Models\Warehouse;
use App\Services\SAP\SapClient;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CalculateStockOpportunitiesJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 3600;

    public function handle(SapClient $sapClient): void
    {
        try {
            // Target Production DB explicitly
            $sapClient->setCompanyDb('PPTC_V5_PROD');

            // 1. Fetch local average daily sales FIRST to find active items
            // Filter strictly to last 7 days of PROD active sales
            $salesData = DB::table('sap_invoice_lines')
                ->join('sap_invoices', 'sap_invoice_lines.sap_invoice_id', '=', 'sap_invoices.id')
                ->leftJoin('warehouses', 'sap_invoices.sales_employee_code', '=', 'warehouses.sales_employee_code')
                ->select(
                    'sap_invoice_lines.item_code',
                    DB::raw('COALESCE(warehouses.warehouse_code, sap_invoice_lines.warehouse_code) as warehouse_code'),
                    DB::raw('SUM(sap_invoice_lines.quantity) / 7 as ads')
                )
                ->whereDate('sap_invoices.doc_date', '>=', now()->subDays(7)->toDateString())
                ->groupBy('sap_invoice_lines.item_code', 'warehouse_code')
                ->get()
                ->groupBy('item_code');

            $activeItemCodes = $salesData->keys()->filter()->toArray();
            $currentStock = []; 

            \App\Models\WarehouseItemStock::truncate();

            // 2. Fetch Stock limits from SAP - ONLY for items that have proven demand somewhere
            if (!empty($activeItemCodes)) {
                $chunks = array_chunk($activeItemCodes, 40); // 40 items per request to keep URL length safe
                
                foreach ($chunks as $chunk) {
                    $filters = array_map(function($code) {
                        return "ItemCode eq '$code'";
                    }, $chunk);
                    
                    $filterString = implode(' or ', $filters);
                    
                    $response = $sapClient->get('Items', [
                        '$select' => 'ItemCode,ItemWarehouseInfoCollection',
                        '$filter' => $filterString,
                    ]);

                    $items = $response['value'] ?? [];
                    
                    foreach ($items as $item) {
                        $itemCode = $item['ItemCode'];
                        if (empty($itemCode)) continue;

                        foreach ($item['ItemWarehouseInfoCollection'] as $whsInfo) {
                            $whsCode = $whsInfo['WarehouseCode'];
                            $inStock = $whsInfo['InStock'] ?? 0;
                            $currentStock[$itemCode][$whsCode] = $inStock;
                            
                            try {
                                \App\Models\WarehouseItemStock::updateOrCreate(
                                    ['item_code' => $itemCode, 'warehouse_code' => $whsCode],
                                    ['in_stock' => $inStock]
                                );
                            } catch (\Exception $e) {}
                        }
                    }
                }
            }

            $warehouses = Warehouse::pluck('warehouse_code')->toArray();
            
            DB::beginTransaction();
            // Delete old pending suggestions
            SuggestedStockTransfer::where('status', 'pending')->delete();

            foreach ($currentStock as $itemCode => $whsStock) {
                $itemSales = $salesData->get($itemCode)?->keyBy('warehouse_code') ?? collect();
                
                $slowMoving = [];
                $highDemand = [];

                foreach ($whsStock as $whsCode => $stock) {
                    // Only process our explicitly watched warehouses, or fallback to any generic mappings if requested
                    if (!in_array($whsCode, $warehouses)) continue;

                    $ads = $itemSales->get($whsCode)->ads ?? 0;
                    $dos = $ads > 0 ? $stock / $ads : 999;
                    
                    // Production Formula: Dos > 90 days, substantial stock (>10), very slow moving
                    if ($dos > 90 && $stock > 10 && $ads < 0.1) {
                        $slowMoving[] = [
                            'warehouse' => $whsCode,
                            'stock' => $stock,
                            'ads' => $ads,
                            'dos' => $dos
                        ];
                    }

                    // Production Formula: Dos < 7 (1 week left), good demand
                    if ($dos < 7 && $ads > 0.5) {
                        $highDemand[] = [
                            'warehouse' => $whsCode,
                            'stock' => $stock,
                            'ads' => $ads,
                            'dos' => $dos
                        ];
                    }
                }

                foreach ($highDemand as $target) {
                    foreach ($slowMoving as &$source) {
                        if ($source['stock'] <= 10) continue; 
                        
                        $requiredQty = ($target['ads'] * 30) - $target['stock'];
                        $availableQty = $source['stock'] - ($source['ads'] * 30);

                        if ($requiredQty > 0 && $availableQty > 0) {
                            $suggestedQty = min($requiredQty, $availableQty);
                            
                            if ($suggestedQty > 0) {
                                SuggestedStockTransfer::create([
                                    'item_code' => $itemCode,
                                    'source_warehouse' => $source['warehouse'],
                                    'target_warehouse' => $target['warehouse'],
                                    'suggested_quantity' => $suggestedQty,
                                    'source_ads' => $source['ads'],
                                    'source_stock' => $source['stock'],
                                    'target_ads' => $target['ads'],
                                    'target_stock' => $target['stock'],
                                ]);
                                
                                $source['stock'] -= $suggestedQty;
                                $target['stock'] += $suggestedQty;
                                break;
                            }
                        }
                    }
                }
            }
            DB::commit();

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error("CalculateStockOpportunitiesJob Failed: " . $e->getMessage());
            throw $e;
        }
    }
}
