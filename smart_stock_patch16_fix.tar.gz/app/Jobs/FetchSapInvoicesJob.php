<?php

namespace App\Jobs;

use App\Models\SapInvoice;
use App\Models\SapInvoiceLine;
use App\Services\SAP\SapClient;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class FetchSapInvoicesJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 3600; // 1 hour

    public function handle(SapClient $sapClient): void
    {
        ini_set('memory_limit', '2048M');
        DB::disableQueryLog();

        $limit = 50;
        $skip = 0;

        try {
            // Target Production DB explicitly
            $sapClient->setCompanyDb('PPTC_V5_PROD');

            // Resume from where it stopped
            $totalFetched = \App\Models\SapInvoice::count();
            $retryCount = 0;

            while (true) {
                try {
                    $response = $sapClient->get('Invoices', [
                        '$filter' => "DocDate ge '2026-01-01'",
                        '$top' => 50,
                        '$skip' => $totalFetched,
                        '$orderby' => 'DocEntry desc',
                    ]);
                    
                    $retryCount = 0; // Reset on success

                    $invoices = $response['value'] ?? [];
                    
                    if (empty($invoices)) {
                        break;
                    }
                    
                    $fetchedCount = count($invoices);
                    Log::info("FetchSapInvoicesJob: Fetched " . $fetchedCount . " invoices from SAP. Total: " . ($totalFetched + $fetchedCount));

                    if (!empty($invoices)) {
                        DB::beginTransaction();
                        foreach ($invoices as $inv) {
                            $sapInvoice = SapInvoice::updateOrCreate(
                                ['doc_num' => $inv['DocNum']],
                                [
                                    'card_code' => $inv['CardCode'] ?? null,
                                    'doc_date' => $inv['DocDate'] ?? null,
                                    'sales_employee_code' => $inv['SalesPersonCode'] ?? null,
                                    'doc_total' => $inv['DocTotal'] ?? 0,
                                ]
                            );

                            if (isset($inv['DocumentLines']) && is_array($inv['DocumentLines'])) {
                                foreach ($inv['DocumentLines'] as $line) {
                                    if (!empty($line['ItemCode'])) {
                                        SapInvoiceLine::updateOrCreate(
                                            [
                                                'sap_invoice_id' => $sapInvoice->id,
                                                'item_code' => $line['ItemCode'],
                                                'warehouse_code' => $line['WarehouseCode'] ?? null,
                                            ],
                                            [
                                                'quantity' => $line['Quantity'] ?? 0,
                                            ]
                                        );
                                    }
                                }
                            }
                        }
                        DB::commit();
                    }
                    
                    $totalFetched += $fetchedCount;
                    unset($invoices, $response);
                    gc_collect_cycles();
                    
                    // Wait 0.5s to prevent SAP from rejecting requests due to rapid API bombardment (502 Bad Gateway)
                    usleep(500000);
                } catch (\Exception $e) {
                    $retryCount++;
                    Log::error("FetchSapInvoicesJob: SAP Transient error at skip {$totalFetched}. Retrying ({$retryCount}/5)... Error: " . $e->getMessage());
                    if ($retryCount >= 5) {
                        Log::error("FetchSapInvoicesJob: Max retries reached. Aborting.");
                        break; // Break the while loop if it fails 5 times consecutively
                    }
                    sleep(3); // Wait 3 seconds before retrying
                }
            } // end while
        } catch (\Exception $e) {
            Log::error("FetchSapInvoicesJob Failed: " . $e->getMessage());
        }
    }
}
